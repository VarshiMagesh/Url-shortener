package main

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/joho/godotenv"

	"gitlab.com/vishal101/url-shortener/internal/cache"
	"gitlab.com/vishal101/url-shortener/internal/codegen"
	"gitlab.com/vishal101/url-shortener/internal/config"
	"gitlab.com/vishal101/url-shortener/internal/db"
	"gitlab.com/vishal101/url-shortener/internal/handler"
	"gitlab.com/vishal101/url-shortener/internal/middleware"
)

func corsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET,POST,PATCH,DELETE,OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Authorization, Content-Type")
		w.Header().Set("Access-Control-Max-Age", "86400")

		if strings.EqualFold(r.Method, http.MethodOptions) {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}

func main() {
	logger := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{
		Level: slog.LevelInfo,
	}))
	slog.SetDefault(logger)

	// Load .env for local development. In production, env vars are supplied externally.
	_ = godotenv.Load()

	cfg, err := config.Load()
	if err != nil {
		logger.Error("failed to load config", "error", err)
		os.Exit(1)
	}

	if err := codegen.Configure(cfg.ShortCodeLength); err != nil {
		logger.Error("failed to configure codegen", "error", err)
		os.Exit(1)
	}

	if err := db.InitDB(cfg, logger); err != nil {
		logger.Error("failed to init mysql", "error", err)
		os.Exit(1)
	}
	db.StartRequestLogsCleanup(cfg, logger)
	defer func() {
		_ = db.Close()
	}()

	if err := cache.InitRedis(cfg, logger); err != nil {
		// Requirement: if Redis is down do not crash.
		logger.Warn("failed to init redis; continuing without cache", "error", err)
	}

	r := chi.NewRouter()
	r.Use(corsMiddleware)

	// Public redirect endpoint: GET /{code}
	r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelRedirect)).
		Get("/{code}", handler.RedirectHandler(cfg, logger))

	// API routes.
	r.Route("/api", func(r chi.Router) {
		r.Use(middleware.RequireAPIKey(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelCreate)).
			Post("/links", handler.CreateLinkHandler(cfg, logger))

		// Default API rate limits.
		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Get("/links", handler.ListLinksHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Get("/links/{code}", handler.GetLinkHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Patch("/links/{code}", handler.PatchLinkHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Delete("/links/{code}", handler.DeleteLinkHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Get("/links/{code}/analytics", handler.LinkAnalyticsHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Get("/analytics", handler.OverallAnalyticsHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Get("/request-stats", handler.RequestStatsHandler(cfg, logger))
	})

	addr := fmt.Sprintf(":%d", cfg.Port)
	srv := &http.Server{
		Addr:              addr,
		Handler:           r,
		ReadHeaderTimeout: 5 * time.Second,
	}

	go func() {
		logger.Info("server starting", "addr", addr)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Error("server error", "error", err)
			os.Exit(1)
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)

	<-quit
	logger.Info("shutdown initiated")

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	if err := srv.Shutdown(ctx); err != nil {
		logger.Error("server shutdown failed", "error", err)
	}

	logger.Info("shutdown complete")
}

