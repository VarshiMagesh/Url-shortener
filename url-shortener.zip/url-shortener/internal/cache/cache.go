package cache

import (
	"context"
	"log/slog"
	"strconv"
	"time"

	"github.com/redis/go-redis/v9"

	"gitlab.com/vishal101/url-shortener/internal/config"
)

// client is initialized by InitRedis.
var client *redis.Client
var defaultTTLSeconds int64
var logger *slog.Logger

// InitRedis connects to Redis. If Redis is unavailable, it leaves cache disabled (Get returns "").
func InitRedis(cfg *config.Config, l *slog.Logger) error {
	if cfg == nil {
		return nil
	}
	if l == nil {
		l = slog.Default()
	}
	logger = l

	defaultTTLSeconds = int64(cfg.CacheDefaultTTL.Seconds())
	if defaultTTLSeconds <= 0 {
		defaultTTLSeconds = 86400
	}

	c := redis.NewClient(&redis.Options{
		Addr:         cfg.RedisHost + ":" + strconv.Itoa(cfg.RedisPort),
		Password:     cfg.RedisPassword,
		DB:           cfg.RedisDB,
		DialTimeout:  cfg.RedisSocketTimeout,
		ReadTimeout:  cfg.RedisSocketTimeout,
		WriteTimeout: cfg.RedisSocketTimeout,
		PoolSize:     cfg.DBMaxOpenConns,
	})

	// Ping with a short timeout; if it fails we keep cache disabled.
	ctx, cancel := context.WithTimeout(context.Background(), cfg.RedisSocketTimeout)
	defer cancel()
	if err := c.Ping(ctx).Err(); err != nil {
		logger.Error("redis unavailable; caching disabled", "error", err)
		client = nil
		return nil
	}

	client = c
	logger.Info("redis connected", "host", cfg.RedisHost, "port", cfg.RedisPort, "db", cfg.RedisDB)
	return nil
}

// RedisClient exposes the underlying redis client.
// It may be nil when caching is disabled.
func RedisClient() *redis.Client {
	return client
}

// DisableRedis closes and clears the global Redis client. Use in tests to avoid cross-test leakage.
func DisableRedis() {
	if client == nil {
		return
	}
	_ = client.Close()
	client = nil
}

func TTLSeconds(expiresAt *time.Time) int64 {
	if expiresAt == nil {
		return defaultTTLSeconds
	}
	expUTC := expiresAt.UTC()
	ttl := int64(expUTC.Sub(time.Now().UTC()).Seconds())
	if ttl <= 0 {
		return 0
	}
	return ttl
}

func Get(ctx context.Context, code string) string {
	if code == "" || client == nil {
		return ""
	}
	val, err := client.Get(ctx, code).Result()
	if err != nil {
		logger.Error("redis get error", "code", code, "error", err)
		return ""
	}
	return val
}

func Set(ctx context.Context, code, url string, ttlSeconds int64) {
	if code == "" || client == nil {
		return
	}
	if ttlSeconds <= 0 {
		return // don't cache already-expired entries
	}
	if err := client.Set(ctx, code, url, time.Duration(ttlSeconds)*time.Second).Err(); err != nil {
		logger.Error("redis set error", "code", code, "error", err)
	}
}

func Delete(ctx context.Context, code string) {
	if code == "" || client == nil {
		return
	}
	if err := client.Del(ctx, code).Err(); err != nil {
		logger.Error("redis delete error", "code", code, "error", err)
	}
}

