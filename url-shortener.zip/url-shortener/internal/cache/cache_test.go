package cache

import (
	"context"
	"io"
	"log/slog"
	"net"
	"strconv"
	"sync"
	"testing"
	"time"

	"github.com/alicebob/miniredis/v2"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"gitlab.com/vishal101/url-shortener/internal/config"
)

func TestCache_TableDriven(t *testing.T) {
	tests := []struct {
		name string
		op   func(t *testing.T, ctx context.Context)
	}{
		{
			name: "set get delete",
			op: func(t *testing.T, ctx context.Context) {
				Set(ctx, "abc", "https://example.com", 10)
				assert.Equal(t, "https://example.com", Get(ctx, "abc"))
				Delete(ctx, "abc")
				assert.Equal(t, "", Get(ctx, "abc"))
			},
		},
		{
			name: "get miss empty string",
			op: func(t *testing.T, ctx context.Context) {
				assert.Equal(t, "", Get(ctx, "no-such-key"))
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			DisableRedis()
			t.Cleanup(DisableRedis)

			mr, err := miniredis.Run()
			require.NoError(t, err)
			t.Cleanup(mr.Close)

			host, portStr, _ := net.SplitHostPort(mr.Addr())
			port, _ := strconv.Atoi(portStr)
			cfg := &config.Config{
				RedisHost:          host,
				RedisPort:          port,
				RedisDB:            0,
				RedisSocketTimeout: 2 * time.Second,
				DBMaxOpenConns:     10,
				CacheDefaultTTL:    24 * time.Hour,
			}
			logger := slog.New(slog.NewJSONHandler(io.Discard, nil))
			require.NoError(t, InitRedis(cfg, logger))

			ctx := context.Background()
			tt.op(t, ctx)
		})
	}
}

func TestCacheConcurrentGet_IsRaceSafeWithMiniredis(t *testing.T) {
	DisableRedis()
	t.Cleanup(DisableRedis)

	mr, err := miniredis.Run()
	require.NoError(t, err)
	t.Cleanup(mr.Close)
	require.NoError(t, mr.Set("shared", "https://x.example"))

	host, portStr, _ := net.SplitHostPort(mr.Addr())
	port, _ := strconv.Atoi(portStr)
	cfg := &config.Config{
		RedisHost:          host,
		RedisPort:          port,
		RedisDB:            0,
		RedisSocketTimeout: 2 * time.Second,
		DBMaxOpenConns:     10,
		CacheDefaultTTL:    24 * time.Hour,
	}
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))
	require.NoError(t, InitRedis(cfg, logger))

	const workers = 64
	var wg sync.WaitGroup
	ok := make([]bool, workers)
	ctx := context.Background()
	wg.Add(workers)
	for w := 0; w < workers; w++ {
		w := w
		go func() {
			defer wg.Done()
			ok[w] = Get(ctx, "shared") == "https://x.example"
		}()
	}
	wg.Wait()
	for _, passed := range ok {
		assert.True(t, passed)
	}
}

func TestCacheRedisFailureFallback(t *testing.T) {
	DisableRedis()
	t.Cleanup(DisableRedis)

	cfg := &config.Config{
		RedisHost:          "127.0.0.1",
		RedisPort:          6399, // typically unavailable
		RedisDB:            0,
		RedisSocketTimeout: 500 * time.Millisecond,
		DBMaxOpenConns:     10,
		CacheDefaultTTL:    24 * time.Hour,
	}
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))
	err := InitRedis(cfg, logger)
	assert.NoError(t, err) // design: does not fail hard

	ctx := context.Background()
	assert.Equal(t, "", Get(ctx, "missing"))
	Set(ctx, "a", "b", 10) // no panic/no crash
	Delete(ctx, "a")
}

