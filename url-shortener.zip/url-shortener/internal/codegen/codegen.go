package codegen

import (
	"crypto/rand"
	"fmt"
	"math/big"
)

const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

var shortCodeLength = 7

// Configure sets the length used by GenerateCode.
func Configure(length int) error {
	if length <= 0 {
		return fmt.Errorf("SHORT_CODE_LENGTH must be > 0")
	}
	shortCodeLength = length
	return nil
}

// GenerateCode returns a random short_code string from the allowed charset.
func GenerateCode() (string, error) {
	if shortCodeLength <= 0 {
		return "", fmt.Errorf("code generator not configured")
	}

	max := big.NewInt(int64(len(charset)))
	out := make([]byte, shortCodeLength)

	for i := 0; i < shortCodeLength; i++ {
		n, err := rand.Int(rand.Reader, max)
		if err != nil {
			return "", err
		}
		out[i] = charset[n.Int64()]
	}

	return string(out), nil
}

