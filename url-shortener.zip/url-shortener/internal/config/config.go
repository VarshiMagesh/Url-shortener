package config

import (
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/joho/godotenv"
)

// Config holds all runtime configuration parsed from environment variables.
type Config struct {
	AppBaseURL string
	Port        int

	DBHost     string
	DBPort     int
	DBName     string
	DBUser     string
	DBPassword string

	DBMaxOpenConns      int
	DBMaxIdleConns      int
	DBConnMaxLifetime   time.Duration
	DBQueryTimeout      time.Duration
	DBQueryTimeoutSec   int
	DBConnMaxLifetimeMin int

	RedisHost          string
	RedisPort          int
	RedisPassword      string
	RedisDB            int
	RedisSocketTimeout time.Duration

	CacheDefaultTTL time.Duration

	APIKeySecret string

	ShortCodeLength int

	IPLookupBaseURL    string
	IPLookupTimeoutSec int
	IPLookupTimeout    time.Duration

	RateLimitRedirectPerMinute   int
	RateLimitAPILinksPostPerMinute int
	RateLimitAPIDefaultPerMinute int
}

func requireString(keys ...string) error {
	var missing []string
	for _, k := range keys {
		if strings.TrimSpace(os.Getenv(k)) == "" {
			missing = append(missing, k)
		}
	}
	if len(missing) == 0 {
		return nil
	}
	return fmt.Errorf("missing required environment variables: %s", strings.Join(missing, ", "))
}

// Load reads configuration using godotenv and environment variables and validates them.
// It returns an error if any required variable is missing or cannot be parsed.
func Load() (*Config, error) {
	// godotenv is used so local development can rely on a .env file.
	// In production (Cloud Run), environment variables will be provided externally.
	_ = godotenv.Load()

	required := []string{
		"APP_BASE_URL",
		"PORT",
		"DB_HOST",
		"DB_PORT",
		"DB_NAME",
		"DB_USER",
		"DB_MAX_OPEN_CONNS",
		"DB_MAX_IDLE_CONNS",
		"DB_CONN_MAX_LIFETIME_MINUTES",
		"DB_QUERY_TIMEOUT_SEC",
		"REDIS_HOST",
		"REDIS_PORT",
		"REDIS_DB",
		"REDIS_SOCKET_TIMEOUT_SEC",
		"CACHE_DEFAULT_TTL_SEC",
		"API_KEY_SECRET",
		"SHORT_CODE_LENGTH",
		"IP_LOOKUP_BASE_URL",
		"IP_LOOKUP_TIMEOUT_SEC",
		"RATE_LIMIT_REDIRECT_PER_MINUTE",
		"RATE_LIMIT_API_LINKS_POST_PER_MINUTE",
		"RATE_LIMIT_API_DEFAULT_PER_MINUTE",
	}
	if err := requireString(required...); err != nil {
		return nil, err
	}

	port, err := strconv.Atoi(os.Getenv("PORT"))
	if err != nil || port <= 0 {
		return nil, fmt.Errorf("invalid PORT: %q", os.Getenv("PORT"))
	}

	dbPort, err := strconv.Atoi(os.Getenv("DB_PORT"))
	if err != nil || dbPort <= 0 {
		return nil, fmt.Errorf("invalid DB_PORT: %q", os.Getenv("DB_PORT"))
	}

	dbMaxOpenConns, err := strconv.Atoi(os.Getenv("DB_MAX_OPEN_CONNS"))
	if err != nil || dbMaxOpenConns <= 0 {
		return nil, fmt.Errorf("invalid DB_MAX_OPEN_CONNS: %q", os.Getenv("DB_MAX_OPEN_CONNS"))
	}

	dbMaxIdleConns, err := strconv.Atoi(os.Getenv("DB_MAX_IDLE_CONNS"))
	if err != nil || dbMaxIdleConns < 0 {
		return nil, fmt.Errorf("invalid DB_MAX_IDLE_CONNS: %q", os.Getenv("DB_MAX_IDLE_CONNS"))
	}

	dbConnMaxLifetimeMin, err := strconv.Atoi(os.Getenv("DB_CONN_MAX_LIFETIME_MINUTES"))
	if err != nil || dbConnMaxLifetimeMin <= 0 {
		return nil, fmt.Errorf("invalid DB_CONN_MAX_LIFETIME_MINUTES: %q", os.Getenv("DB_CONN_MAX_LIFETIME_MINUTES"))
	}

	dbQueryTimeoutSec, err := strconv.Atoi(os.Getenv("DB_QUERY_TIMEOUT_SEC"))
	if err != nil || dbQueryTimeoutSec <= 0 {
		return nil, fmt.Errorf("invalid DB_QUERY_TIMEOUT_SEC: %q", os.Getenv("DB_QUERY_TIMEOUT_SEC"))
	}

	redisPort, err := strconv.Atoi(os.Getenv("REDIS_PORT"))
	if err != nil || redisPort <= 0 {
		return nil, fmt.Errorf("invalid REDIS_PORT: %q", os.Getenv("REDIS_PORT"))
	}
	redisDB, err := strconv.Atoi(os.Getenv("REDIS_DB"))
	if err != nil || redisDB < 0 {
		return nil, fmt.Errorf("invalid REDIS_DB: %q", os.Getenv("REDIS_DB"))
	}
	redisSocketTimeoutSec, err := strconv.Atoi(os.Getenv("REDIS_SOCKET_TIMEOUT_SEC"))
	if err != nil || redisSocketTimeoutSec <= 0 {
		return nil, fmt.Errorf("invalid REDIS_SOCKET_TIMEOUT_SEC: %q", os.Getenv("REDIS_SOCKET_TIMEOUT_SEC"))
	}

	cacheDefaultTTLSec, err := strconv.Atoi(os.Getenv("CACHE_DEFAULT_TTL_SEC"))
	if err != nil || cacheDefaultTTLSec <= 0 {
		return nil, fmt.Errorf("invalid CACHE_DEFAULT_TTL_SEC: %q", os.Getenv("CACHE_DEFAULT_TTL_SEC"))
	}

	shortCodeLength, err := strconv.Atoi(os.Getenv("SHORT_CODE_LENGTH"))
	if err != nil || shortCodeLength <= 0 || shortCodeLength > 50 {
		return nil, fmt.Errorf("invalid SHORT_CODE_LENGTH: %q", os.Getenv("SHORT_CODE_LENGTH"))
	}

	ipLookupTimeoutSec, err := strconv.Atoi(os.Getenv("IP_LOOKUP_TIMEOUT_SEC"))
	if err != nil || ipLookupTimeoutSec <= 0 {
		return nil, fmt.Errorf("invalid IP_LOOKUP_TIMEOUT_SEC: %q", os.Getenv("IP_LOOKUP_TIMEOUT_SEC"))
	}

	rateRedirect, err := strconv.Atoi(os.Getenv("RATE_LIMIT_REDIRECT_PER_MINUTE"))
	if err != nil || rateRedirect <= 0 {
		return nil, fmt.Errorf("invalid RATE_LIMIT_REDIRECT_PER_MINUTE: %q", os.Getenv("RATE_LIMIT_REDIRECT_PER_MINUTE"))
	}
	rateCreate, err := strconv.Atoi(os.Getenv("RATE_LIMIT_API_LINKS_POST_PER_MINUTE"))
	if err != nil || rateCreate <= 0 {
		return nil, fmt.Errorf("invalid RATE_LIMIT_API_LINKS_POST_PER_MINUTE: %q", os.Getenv("RATE_LIMIT_API_LINKS_POST_PER_MINUTE"))
	}
	rateDefault, err := strconv.Atoi(os.Getenv("RATE_LIMIT_API_DEFAULT_PER_MINUTE"))
	if err != nil || rateDefault <= 0 {
		return nil, fmt.Errorf("invalid RATE_LIMIT_API_DEFAULT_PER_MINUTE: %q", os.Getenv("RATE_LIMIT_API_DEFAULT_PER_MINUTE"))
	}

	appBaseURL := strings.TrimSpace(os.Getenv("APP_BASE_URL"))
	if appBaseURL == "" {
		return nil, errors.New("APP_BASE_URL must not be empty")
	}

	// Normalize base URL so handler code can safely append "/{code}".
	appBaseURL = strings.TrimRight(appBaseURL, "/")

	cfg := &Config{
		AppBaseURL: appBaseURL,
		Port:        port,

		DBHost:     os.Getenv("DB_HOST"),
		DBPort:     dbPort,
		DBName:     os.Getenv("DB_NAME"),
		DBUser:     os.Getenv("DB_USER"),
		DBPassword: os.Getenv("DB_PASSWORD"),

		DBMaxOpenConns:    dbMaxOpenConns,
		DBMaxIdleConns:    dbMaxIdleConns,
		DBConnMaxLifetime: time.Duration(dbConnMaxLifetimeMin) * time.Minute,
		DBQueryTimeout:    time.Duration(dbQueryTimeoutSec) * time.Second,
		DBQueryTimeoutSec: dbQueryTimeoutSec,
		DBConnMaxLifetimeMin: dbConnMaxLifetimeMin,

		RedisHost:          os.Getenv("REDIS_HOST"),
		RedisPort:          redisPort,
		RedisPassword:      os.Getenv("REDIS_PASSWORD"),
		RedisDB:            redisDB,
		RedisSocketTimeout: time.Duration(redisSocketTimeoutSec) * time.Second,

		CacheDefaultTTL: time.Duration(cacheDefaultTTLSec) * time.Second,

		APIKeySecret: os.Getenv("API_KEY_SECRET"),

		ShortCodeLength: shortCodeLength,

		IPLookupBaseURL:    os.Getenv("IP_LOOKUP_BASE_URL"),
		IPLookupTimeoutSec: ipLookupTimeoutSec,
		IPLookupTimeout:    time.Duration(ipLookupTimeoutSec) * time.Second,

		RateLimitRedirectPerMinute:   rateRedirect,
		RateLimitAPILinksPostPerMinute: rateCreate,
		RateLimitAPIDefaultPerMinute: rateDefault,
	}

	if strings.TrimSpace(cfg.APIKeySecret) == "" {
		return nil, errors.New("API_KEY_SECRET must not be empty")
	}
	if !strings.HasPrefix(cfg.IPLookupBaseURL, "http://") && !strings.HasPrefix(cfg.IPLookupBaseURL, "https://") {
		return nil, fmt.Errorf("invalid IP_LOOKUP_BASE_URL: %q", cfg.IPLookupBaseURL)
	}

	return cfg, nil
}

