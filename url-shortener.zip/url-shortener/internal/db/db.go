package db

import (
	"context"
	"database/sql"
	"fmt"
	"log/slog"
	"time"

	_ "github.com/go-sql-driver/mysql"

	"gitlab.com/vishal101/url-shortener/internal/config"
)

// DB is the shared database handle.
var DB *sql.DB

// InitDB opens the MySQL connection pool and validates it via PingContext.
func InitDB(cfg *config.Config, logger *slog.Logger) error {
	if cfg == nil {
		return fmt.Errorf("config is nil")
	}
	if logger == nil {
		logger = slog.Default()
	}

	// parseTime=true helps scanning DATETIME/TIMESTAMP values into time.Time.
	// interpolateParams=true allows using `?` placeholders with prepared statements.
	// loc=Asia%2FKolkata ensures parsed times are represented in IST.
	dsn := fmt.Sprintf(
		"%s:%s@tcp(%s:%d)/%s?parseTime=true&loc=Asia%%2FKolkata&charset=utf8mb4&interpolateParams=true",
		cfg.DBUser,
		cfg.DBPassword,
		cfg.DBHost,
		cfg.DBPort,
		cfg.DBName,
	)

	var err error
	DB, err = sql.Open("mysql", dsn)
	if err != nil {
		return fmt.Errorf("sql.Open: %w", err)
	}

	DB.SetMaxOpenConns(cfg.DBMaxOpenConns)
	DB.SetMaxIdleConns(cfg.DBMaxIdleConns)
	DB.SetConnMaxLifetime(cfg.DBConnMaxLifetime)

	ctx, cancel := context.WithTimeout(context.Background(), cfg.DBQueryTimeout)
	defer cancel()

	if err := DB.PingContext(ctx); err != nil {
		return fmt.Errorf("db ping: %w", err)
	}

	logger.Info("mysql connected", "host", cfg.DBHost, "port", cfg.DBPort, "db", cfg.DBName, "max_open_conns", cfg.DBMaxOpenConns)
	return nil
}

func Close() error {
	if DB == nil {
		return nil
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = ctx // no direct sql.DB close context; kept for symmetry/future.
	return DB.Close()
}

// StartRequestLogsCleanup removes request log rows older than 24 hours every 1 hour.
// It runs in a background goroutine and logs failures without crashing the app.
func StartRequestLogsCleanup(cfg *config.Config, logger *slog.Logger) {
	if cfg == nil || DB == nil {
		return
	}
	if logger == nil {
		logger = slog.Default()
	}

	go func() {
		ticker := time.NewTicker(1 * time.Hour)
		defer ticker.Stop()

		for {
			<-ticker.C
			ctx, cancel := context.WithTimeout(context.Background(), cfg.DBQueryTimeout)
			res, err := DB.ExecContext(
				ctx,
				`DELETE FROM request_logs 
				 WHERE requested_at < (UTC_TIMESTAMP() - INTERVAL 24 HOUR)`,
			)
			cancel()
			if err != nil {
				logger.Warn("request_logs cleanup failed", "error", err)
				continue
			}

			rowsDeleted, err := res.RowsAffected()
			if err != nil {
				logger.Warn("request_logs cleanup rows affected read failed", "error", err)
				continue
			}
			logger.Info("request_logs cleanup completed", "rows_deleted", rowsDeleted)
		}
	}()
}

