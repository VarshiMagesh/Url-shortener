package db

import (
	"context"
	"database/sql"
	"io"
	"log/slog"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/stretchr/testify/assert"

	"gitlab.com/vishal101/url-shortener/internal/config"
)

func TestCloseNilDB(t *testing.T) {
	DB = nil
	assert.NoError(t, Close())
}

func TestStartRequestLogsCleanupNilSafe(t *testing.T) {
	DB = nil
	cfg := &config.Config{DBQueryTimeout: 3 * time.Second}
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))
	StartRequestLogsCleanup(cfg, logger) // should not panic
}

func TestDBTimeoutHandlingViaContext(t *testing.T) {
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock: %v", err)
	}
	defer sqlDB.Close()
	DB = sqlDB

	mock.ExpectQuery("SELECT 1").WillDelayFor(50 * time.Millisecond).
		WillReturnRows(sqlmock.NewRows([]string{"n"}).AddRow(1))

	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Millisecond)
	defer cancel()

	var n int
	err = DB.QueryRowContext(ctx, "SELECT 1").Scan(&n)
	assert.Error(t, err)
}

func TestInsertAndFetchWithSqlmock(t *testing.T) {
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock: %v", err)
	}
	defer sqlDB.Close()
	DB = sqlDB

	mock.ExpectExec("INSERT INTO urls").
		WithArgs("code1234", "https://example.com", sqlmock.AnyArg(), sql.NullTime{}, true).
		WillReturnResult(sqlmock.NewResult(1, 1))

	_, err = DB.ExecContext(context.Background(),
		"INSERT INTO urls (short_code, long_url, created_by, expires_at, is_active) VALUES (?, ?, ?, ?, ?)",
		"code1234", "https://example.com", nil, sql.NullTime{}, true,
	)
	assert.NoError(t, err)

	mock.ExpectQuery("SELECT id, short_code FROM urls WHERE short_code = ?").
		WithArgs("code1234").
		WillReturnRows(sqlmock.NewRows([]string{"id", "short_code"}).AddRow(1, "code1234"))

	var id int64
	var code string
	err = DB.QueryRowContext(context.Background(), "SELECT id, short_code FROM urls WHERE short_code = ?", "code1234").Scan(&id, &code)
	assert.NoError(t, err)
	assert.Equal(t, int64(1), id)
	assert.Equal(t, "code1234", code)
}

