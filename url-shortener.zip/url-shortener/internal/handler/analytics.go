package handler

import (
	"context"
	"database/sql"
	"errors"
	"log/slog"
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"

	"gitlab.com/vishal101/url-shortener/internal/config"
	"gitlab.com/vishal101/url-shortener/internal/db"
)

type dayClicks struct {
	Day    string `json:"day"`
	Clicks int64  `json:"clicks"`
}

type pairClicks struct {
	Key    string `json:"key"`
	Clicks int64  `json:"clicks"`
}

type linkAnalyticsResponse struct {
	TotalClicks  int64       `json:"total_clicks"`
	ClicksByDay  []dayClicks `json:"clicks_by_day"`
	TopReferrers []pairClicks `json:"top_referrers"`
	TopCountries []pairClicks `json:"top_countries"`
	TopDevices   []pairClicks `json:"top_devices"`
}

type overallLink struct {
	ShortCode string `json:"short_code"`
	LongURL   string `json:"long_url"`
	Clicks    int64  `json:"clicks"`
}

type overallAnalyticsResponse struct {
	TotalLinks int64        `json:"total_links"`
	TotalClicks int64      `json:"total_clicks"`
	TopLinks   []overallLink `json:"top_links"`
	ClicksByDay []dayClicks  `json:"clicks_by_day"`
}

type requestIPStat struct {
	IPAddress    string `json:"ip_address"`
	RequestCount int64  `json:"request_count"`
}

type requestEndpointStat struct {
	Endpoint     string `json:"endpoint"`
	RequestCount int64  `json:"request_count"`
}

type requestStatsResponse struct {
	TopIPs               []requestIPStat       `json:"top_ips"`
	RequestsByEndpoint   []requestEndpointStat `json:"requests_by_endpoint"`
	TotalRequestsLast24h int64                 `json:"total_requests_last_24h"`
	BlockedRequestsLast24h int64               `json:"blocked_requests_last_24h"`
}

func LinkAnalyticsHandler(cfg *config.Config, logger *slog.Logger) http.HandlerFunc {
	if logger == nil {
		logger = slog.Default()
	}

	return func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		code := chi.URLParam(r, "code")
		if code == "" {
			writeError(w, http.StatusNotFound, "Link not found")
			return
		}

		ctx, cancel := context.WithTimeout(r.Context(), cfg.DBQueryTimeout)
		defer cancel()

		var urlID int64
		err := db.DB.QueryRowContext(ctx, `SELECT id FROM urls WHERE short_code = ? LIMIT 1`, code).Scan(&urlID)
		if err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				writeError(w, http.StatusNotFound, "Link not found")
				return
			}
			logger.Error("link analytics: url_id lookup failed", "error", err, "code", code)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		var totalClicks int64
		if err := db.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM clicks WHERE url_id = ?`, urlID).Scan(&totalClicks); err != nil {
			logger.Error("link analytics: total clicks failed", "error", err, "url_id", urlID)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		clicksByDay := make([]dayClicks, 0)
		{
			rows, err := db.DB.QueryContext(
				ctx,
				`SELECT DATE(clicked_at) AS day, COUNT(*) AS clicks
				 FROM clicks
				 WHERE url_id = ?
					AND clicked_at >= UTC_TIMESTAMP() - INTERVAL 30 DAY
				 GROUP BY day
				 ORDER BY day`,
				urlID,
			)
			if err != nil {
				logger.Error("link analytics: clicks_by_day query failed", "error", err, "url_id", urlID)
				writeError(w, http.StatusInternalServerError, "Internal error")
				return
			}
			defer rows.Close()
			for rows.Next() {
				var day time.Time
				var clicks int64
				if err := rows.Scan(&day, &clicks); err != nil {
					logger.Error("link analytics: clicks_by_day scan failed", "error", err, "url_id", urlID)
					writeError(w, http.StatusInternalServerError, "Internal error")
					return
				}
				clicksByDay = append(clicksByDay, dayClicks{Day: day.UTC().Format("2006-01-02"), Clicks: clicks})
			}
		}

		topReferrers := make([]pairClicks, 0)
		{
			rows, err := db.DB.QueryContext(
				ctx,
				`SELECT referrer, COUNT(*) AS clicks
				 FROM clicks
				 WHERE url_id = ?
					AND referrer IS NOT NULL AND referrer <> ''
				 GROUP BY referrer
				 ORDER BY clicks DESC
				 LIMIT 5`,
				urlID,
			)
			if err != nil {
				logger.Error("link analytics: top_referrers query failed", "error", err, "url_id", urlID)
				writeError(w, http.StatusInternalServerError, "Internal error")
				return
			}
			defer rows.Close()
			for rows.Next() {
				var key sql.NullString
				var clicks int64
				if err := rows.Scan(&key, &clicks); err != nil {
					logger.Error("link analytics: top_referrers scan failed", "error", err, "url_id", urlID)
					writeError(w, http.StatusInternalServerError, "Internal error")
					return
				}
				if key.Valid {
					topReferrers = append(topReferrers, pairClicks{Key: key.String, Clicks: clicks})
				}
			}
		}

		topCountries := make([]pairClicks, 0)
		{
			rows, err := db.DB.QueryContext(
				ctx,
				`SELECT country, COUNT(*) AS clicks
				 FROM clicks
				 WHERE url_id = ?
					AND country IS NOT NULL AND country <> ''
				 GROUP BY country
				 ORDER BY clicks DESC
				 LIMIT 5`,
				urlID,
			)
			if err != nil {
				logger.Error("link analytics: top_countries query failed", "error", err, "url_id", urlID)
				writeError(w, http.StatusInternalServerError, "Internal error")
				return
			}
			defer rows.Close()
			for rows.Next() {
				var key sql.NullString
				var clicks int64
				if err := rows.Scan(&key, &clicks); err != nil {
					logger.Error("link analytics: top_countries scan failed", "error", err, "url_id", urlID)
					writeError(w, http.StatusInternalServerError, "Internal error")
					return
				}
				if key.Valid {
					topCountries = append(topCountries, pairClicks{Key: key.String, Clicks: clicks})
				}
			}
		}

		topDevices := make([]pairClicks, 0)
		{
			rows, err := db.DB.QueryContext(
				ctx,
				`SELECT user_agent, COUNT(*) AS clicks
				 FROM clicks
				 WHERE url_id = ?
					AND user_agent IS NOT NULL AND user_agent <> ''
				 GROUP BY user_agent
				 ORDER BY clicks DESC
				 LIMIT 5`,
				urlID,
			)
			if err != nil {
				logger.Error("link analytics: top_devices query failed", "error", err, "url_id", urlID)
				writeError(w, http.StatusInternalServerError, "Internal error")
				return
			}
			defer rows.Close()
			for rows.Next() {
				var key sql.NullString
				var clicks int64
				if err := rows.Scan(&key, &clicks); err != nil {
					logger.Error("link analytics: top_devices scan failed", "error", err, "url_id", urlID)
					writeError(w, http.StatusInternalServerError, "Internal error")
					return
				}
				if key.Valid {
					topDevices = append(topDevices, pairClicks{Key: key.String, Clicks: clicks})
				}
			}
		}

		resp := linkAnalyticsResponse{
			TotalClicks:  totalClicks,
			ClicksByDay:  clicksByDay,
			TopReferrers: topReferrers,
			TopCountries: topCountries,
			TopDevices:   topDevices,
		}

		writeJSON(w, http.StatusOK, resp)
		logger.Info("link analytics served", "code", code, "response_time_ms", time.Since(start).Milliseconds())
	}
}

func OverallAnalyticsHandler(cfg *config.Config, logger *slog.Logger) http.HandlerFunc {
	if logger == nil {
		logger = slog.Default()
	}

	return func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()

		ctx, cancel := context.WithTimeout(r.Context(), cfg.DBQueryTimeout)
		defer cancel()

		var totalLinks int64
		if err := db.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM urls`).Scan(&totalLinks); err != nil {
			logger.Error("overall analytics: total_links query failed", "error", err)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		var totalClicks int64
		if err := db.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM clicks`).Scan(&totalClicks); err != nil {
			logger.Error("overall analytics: total_clicks query failed", "error", err)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		topLinks := make([]overallLink, 0)
		{
			rows, err := db.DB.QueryContext(
				ctx,
				`SELECT u.short_code, u.long_url, COALESCE(COUNT(c.id), 0) AS clicks
				 FROM urls u
				 LEFT JOIN clicks c ON c.url_id = u.id
				 GROUP BY u.id
				 ORDER BY clicks DESC
				 LIMIT 10`,
			)
			if err != nil {
				logger.Error("overall analytics: top_links query failed", "error", err)
				writeError(w, http.StatusInternalServerError, "Internal error")
				return
			}
			defer rows.Close()
			for rows.Next() {
				var item overallLink
				if err := rows.Scan(&item.ShortCode, &item.LongURL, &item.Clicks); err != nil {
					logger.Error("overall analytics: top_links scan failed", "error", err)
					writeError(w, http.StatusInternalServerError, "Internal error")
					return
				}
				topLinks = append(topLinks, item)
			}
		}

		clicksByDay := make([]dayClicks, 0)
		{
			rows, err := db.DB.QueryContext(
				ctx,
				`SELECT DATE(clicked_at) AS day, COUNT(*) AS clicks
				 FROM clicks
				 WHERE clicked_at >= UTC_TIMESTAMP() - INTERVAL 30 DAY
				 GROUP BY day
				 ORDER BY day`,
			)
			if err != nil {
				logger.Error("overall analytics: clicks_by_day query failed", "error", err)
				writeError(w, http.StatusInternalServerError, "Internal error")
				return
			}
			defer rows.Close()
			for rows.Next() {
				var day time.Time
				var clicks int64
				if err := rows.Scan(&day, &clicks); err != nil {
					logger.Error("overall analytics: clicks_by_day scan failed", "error", err)
					writeError(w, http.StatusInternalServerError, "Internal error")
					return
				}
				clicksByDay = append(clicksByDay, dayClicks{Day: day.UTC().Format("2006-01-02"), Clicks: clicks})
			}
		}

		writeJSON(w, http.StatusOK, overallAnalyticsResponse{
			TotalLinks:  totalLinks,
			TotalClicks: totalClicks,
			TopLinks:    topLinks,
			ClicksByDay: clicksByDay,
		})
		logger.Info("overall analytics served", "response_time_ms", time.Since(start).Milliseconds())
	}
}

func RequestStatsHandler(cfg *config.Config, logger *slog.Logger) http.HandlerFunc {
	if logger == nil {
		logger = slog.Default()
	}

	return func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), cfg.DBQueryTimeout)
		defer cancel()

		topIPs := make([]requestIPStat, 0)
		{
			rows, err := db.DB.QueryContext(
				ctx,
				`SELECT ip_address, COUNT(*) AS request_count
				 FROM request_logs
				 WHERE requested_at >= (UTC_TIMESTAMP() - INTERVAL 24 HOUR)
				 GROUP BY ip_address
				 ORDER BY request_count DESC
				 LIMIT 20`,
			)
			if err != nil {
				logger.Error("request stats: top_ips query failed", "error", err)
				writeError(w, http.StatusInternalServerError, "Internal error")
				return
			}
			defer rows.Close()
			for rows.Next() {
				var item requestIPStat
				if err := rows.Scan(&item.IPAddress, &item.RequestCount); err != nil {
					logger.Error("request stats: top_ips scan failed", "error", err)
					writeError(w, http.StatusInternalServerError, "Internal error")
					return
				}
				topIPs = append(topIPs, item)
			}
		}

		byEndpoint := make([]requestEndpointStat, 0)
		{
			rows, err := db.DB.QueryContext(
				ctx,
				`SELECT endpoint, COUNT(*) AS request_count
				 FROM request_logs
				 WHERE requested_at >= (UTC_TIMESTAMP() - INTERVAL 24 HOUR)
				 GROUP BY endpoint
				 ORDER BY request_count DESC`,
			)
			if err != nil {
				logger.Error("request stats: requests_by_endpoint query failed", "error", err)
				writeError(w, http.StatusInternalServerError, "Internal error")
				return
			}
			defer rows.Close()
			for rows.Next() {
				var item requestEndpointStat
				if err := rows.Scan(&item.Endpoint, &item.RequestCount); err != nil {
					logger.Error("request stats: requests_by_endpoint scan failed", "error", err)
					writeError(w, http.StatusInternalServerError, "Internal error")
					return
				}
				byEndpoint = append(byEndpoint, item)
			}
		}

		var total24h int64
		if err := db.DB.QueryRowContext(
			ctx,
			`SELECT COUNT(*) FROM request_logs
			 WHERE requested_at >= (UTC_TIMESTAMP() - INTERVAL 24 HOUR)`,
		).Scan(&total24h); err != nil {
			logger.Error("request stats: total_requests_last_24h query failed", "error", err)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		writeJSON(w, http.StatusOK, requestStatsResponse{
			TopIPs:                 topIPs,
			RequestsByEndpoint:     byEndpoint,
			TotalRequestsLast24h:   total24h,
			BlockedRequestsLast24h: 0,
		})
	}
}

