package handler

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"gitlab.com/vishal101/url-shortener/internal/db"
)

func setupAnalyticsDB(t *testing.T) (sqlmock.Sqlmock, func()) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock: %v", err)
	}
	db.DB = sqlDB
	return mock, func() { _ = sqlDB.Close() }
}

func TestLinkAnalytics_TableDriven(t *testing.T) {
	mock, done := setupAnalyticsDB(t)
	defer done()
	cfg := testConfig()

	mock.ExpectQuery(`SELECT id FROM urls`).
		WithArgs("abc1234").
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(10))
	mock.ExpectQuery(`SELECT COUNT\(\*\) FROM clicks`).
		WithArgs(int64(10)).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(2))
	mock.ExpectQuery(`SELECT DATE\(clicked_at\) AS day, COUNT\(\*\) AS clicks FROM clicks`).
		WithArgs(int64(10)).
		WillReturnRows(sqlmock.NewRows([]string{"day", "clicks"}).AddRow(time.Date(2025, 1, 2, 0, 0, 0, 0, time.UTC), 2))
	mock.ExpectQuery(`SELECT referrer, COUNT\(\*\) AS clicks FROM clicks`).
		WithArgs(int64(10)).
		WillReturnRows(sqlmock.NewRows([]string{"referrer", "clicks"}).AddRow("google.com", 2))
	mock.ExpectQuery(`SELECT country, COUNT\(\*\) AS clicks FROM clicks`).
		WithArgs(int64(10)).
		WillReturnRows(sqlmock.NewRows([]string{"country", "clicks"}).AddRow("India", 2))
	mock.ExpectQuery(`SELECT user_agent, COUNT\(\*\) AS clicks FROM clicks`).
		WithArgs(int64(10)).
		WillReturnRows(sqlmock.NewRows([]string{"user_agent", "clicks"}).AddRow("Chrome", 2))

	req := httptest.NewRequest(http.MethodGet, "/api/links/abc1234/analytics", nil)
	req = addChiURLParam(req, "code", "abc1234")
	rr := httptest.NewRecorder()
	LinkAnalyticsHandler(cfg, testLogger()).ServeHTTP(rr, req)

	require.Equal(t, http.StatusOK, rr.Code)

	var resp linkAnalyticsResponse
	require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &resp))
	assert.EqualValues(t, 2, resp.TotalClicks)
	require.Len(t, resp.ClicksByDay, 1)
	assert.Equal(t, "2025-01-02", resp.ClicksByDay[0].Day)
	assert.EqualValues(t, 2, resp.ClicksByDay[0].Clicks)
	require.Len(t, resp.TopReferrers, 1)
	assert.Equal(t, "google.com", resp.TopReferrers[0].Key)
	require.Len(t, resp.TopCountries, 1)
	assert.Equal(t, "India", resp.TopCountries[0].Key)
	require.Len(t, resp.TopDevices, 1)
	assert.Equal(t, "Chrome", resp.TopDevices[0].Key)
}

func TestOverallAnalytics_TableDriven(t *testing.T) {
	mock, done := setupAnalyticsDB(t)
	defer done()
	cfg := testConfig()

	mock.ExpectQuery(`SELECT COUNT\(\*\) FROM urls`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`SELECT COUNT\(\*\) FROM clicks`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`SELECT u.short_code, u.long_url, COALESCE\(COUNT\(c.id\), 0\) AS clicks FROM urls u`).
		WillReturnRows(sqlmock.NewRows([]string{"short_code", "long_url", "clicks"}))
	mock.ExpectQuery(`SELECT DATE\(clicked_at\) AS day, COUNT\(\*\) AS clicks FROM clicks`).
		WillReturnRows(sqlmock.NewRows([]string{"day", "clicks"}))

	req := httptest.NewRequest(http.MethodGet, "/api/analytics", nil)
	rr := httptest.NewRecorder()
	OverallAnalyticsHandler(cfg, testLogger()).ServeHTTP(rr, req)

	require.Equal(t, http.StatusOK, rr.Code)

	var resp overallAnalyticsResponse
	require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &resp))
	assert.EqualValues(t, 0, resp.TotalLinks)
	assert.EqualValues(t, 0, resp.TotalClicks)
	assert.Empty(t, resp.TopLinks)
	assert.Empty(t, resp.ClicksByDay)
}
