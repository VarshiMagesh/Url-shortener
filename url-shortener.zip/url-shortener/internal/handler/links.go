package handler

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"log/slog"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"

	"gitlab.com/vishal101/url-shortener/internal/cache"
	"gitlab.com/vishal101/url-shortener/internal/codegen"
	"gitlab.com/vishal101/url-shortener/internal/config"
	"gitlab.com/vishal101/url-shortener/internal/db"
)

func writeJSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}

func writeError(w http.ResponseWriter, status int, message string) {
	writeJSON(w, status, map[string]any{"message": message})
}

func nullTimeToPtr(nt sql.NullTime) *time.Time {
	if !nt.Valid {
		return nil
	}
	t := nt.Time.UTC()
	return &t
}

type linkModel struct {
	ID         int64
	ShortCode  string
	LongURL    string
	CreatedBy  sql.NullString
	CreatedAt  time.Time
	ExpiresAt  sql.NullTime
	IsActive   bool
	ClickCount int64
}

type linkResponse struct {
	ID         int64      `json:"id"`
	ShortCode  string     `json:"short_code"`
	LongURL    string     `json:"long_url"`
	CreatedBy  *string    `json:"created_by,omitempty"`
	CreatedAt  time.Time  `json:"created_at"`
	ExpiresAt  *time.Time `json:"expires_at,omitempty"`
	IsActive   bool       `json:"is_active"`
	ClickCount int64      `json:"click_count"`
}

type createLinkResponse struct {
	ShortCode string     `json:"short_code"`
	ShortURL  string     `json:"short_url"`
	LongURL   string     `json:"long_url"`
	ExpiresAt *time.Time `json:"expires_at"`
	CreatedBy *string    `json:"created_by"`
}

func toLinkResponse(m linkModel) linkResponse {
	var createdBy *string
	if m.CreatedBy.Valid {
		v := m.CreatedBy.String
		createdBy = &v
	}

	return linkResponse{
		ID:         m.ID,
		ShortCode:  m.ShortCode,
		LongURL:    m.LongURL,
		CreatedBy:  createdBy,
		CreatedAt:  m.CreatedAt.UTC(),
		ExpiresAt:  nullTimeToPtr(m.ExpiresAt),
		IsActive:   m.IsActive,
		ClickCount: m.ClickCount,
	}
}

func getLinkByCode(ctx context.Context, code string) (linkModel, error) {
	var m linkModel
	err := db.DB.QueryRowContext(
		ctx,
		`SELECT id, short_code, long_url, created_by, created_at, expires_at, is_active
		 FROM urls
		 WHERE short_code = ?
		 LIMIT 1`,
		code,
	).Scan(&m.ID, &m.ShortCode, &m.LongURL, &m.CreatedBy, &m.CreatedAt, &m.ExpiresAt, &m.IsActive)
	return m, err
}

func getLinkByCodeWithClicks(ctx context.Context, code string) (linkModel, error) {
	var m linkModel
	err := db.DB.QueryRowContext(
		ctx,
		`SELECT u.id, u.short_code, u.long_url, u.created_by, u.created_at, u.expires_at, u.is_active,
		        COALESCE(COUNT(c.id), 0) AS click_count
		 FROM urls u
		 LEFT JOIN clicks c ON c.url_id = u.id
		 WHERE u.short_code = ?
		 GROUP BY u.id
		 LIMIT 1`,
		code,
	).Scan(
		&m.ID,
		&m.ShortCode,
		&m.LongURL,
		&m.CreatedBy,
		&m.CreatedAt,
		&m.ExpiresAt,
		&m.IsActive,
		&m.ClickCount,
	)
	return m, err
}

func setExpiresAtFromRaw(raw json.RawMessage) (sql.NullTime, error) {
	if string(raw) == "null" {
		return sql.NullTime{Valid: false}, nil
	}
	var t time.Time
	if err := json.Unmarshal(raw, &t); err != nil {
		return sql.NullTime{}, err
	}
	return sql.NullTime{Valid: true, Time: t.UTC()}, nil
}

// CreateLinkHandler implements POST /api/links
func CreateLinkHandler(cfg *config.Config, logger *slog.Logger) http.HandlerFunc {
	if logger == nil {
		logger = slog.Default()
	}

	return func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		ctx, cancel := context.WithTimeout(r.Context(), cfg.DBQueryTimeout)
		defer cancel()

		var body map[string]any
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			writeError(w, http.StatusBadRequest, "Invalid JSON body")
			return
		}

		longURLRaw, ok := body["long_url"]
		if !ok {
			writeError(w, http.StatusBadRequest, "long_url is required")
			return
		}
		longURL, ok := longURLRaw.(string)
		if !ok || strings.TrimSpace(longURL) == "" {
			writeError(w, http.StatusBadRequest, "long_url must be a non-empty string")
			return
		}
		longURL = strings.TrimSpace(longURL)

		// Validate URL format early so invalid inputs do not reach the DB.
		// For this service we require an absolute URL with scheme + host.
		parsed, err := url.ParseRequestURI(longURL)
		if err != nil || parsed == nil || parsed.Scheme == "" || parsed.Host == "" {
			writeError(w, http.StatusBadRequest, "long_url must be a valid URL")
			return
		}

		creator := sql.NullString{Valid: false}
		if v, ok := body["created_by"]; ok {
			if s, ok := v.(string); ok && strings.TrimSpace(s) != "" {
				creator = sql.NullString{Valid: true, String: strings.TrimSpace(s)}
			}
		}

		isActive := true
		if v, ok := body["is_active"]; ok {
			if b, ok := v.(bool); ok {
				isActive = b
			} else if v == nil {
				// ignore null -> keep default
			} else {
				writeError(w, http.StatusBadRequest, "is_active must be a boolean")
				return
			}
		}

		var expires sql.NullTime
		if v, ok := body["expires_at"]; ok && v != nil {
			// json.Decoder into interface{} results in string for timestamps.
			if s, ok := v.(string); ok {
				t, err := time.Parse(time.RFC3339, s)
				if err != nil {
					writeError(w, http.StatusBadRequest, "expires_at must be RFC3339 timestamp string")
					return
				}
				expires = sql.NullTime{Valid: true, Time: t.UTC()}
			} else {
				writeError(w, http.StatusBadRequest, "expires_at must be RFC3339 timestamp string")
				return
			}
		}

		var (
			shortCode     string
			aliasTaken    string
			autoGenerated bool
		)

		// Alias handling.
		if v, ok := body["alias"]; ok && v != nil {
			aliasStr, ok := v.(string)
			if !ok {
				writeError(w, http.StatusBadRequest, "alias must be a string")
				return
			}
			aliasStr = strings.TrimSpace(aliasStr)
			if aliasStr == "" {
				writeError(w, http.StatusBadRequest, "alias must not be empty")
				return
			}
			if len(aliasStr) > 20 {
				writeError(w, http.StatusBadRequest, "alias maximum length is 20")
				return
			}

			// Check uniqueness before insert.
			var exists int
			if err := db.DB.QueryRowContext(ctx, `SELECT EXISTS(SELECT 1 FROM urls WHERE short_code = ? LIMIT 1)`, aliasStr).Scan(&exists); err != nil {
				if errors.Is(err, context.DeadlineExceeded) {
					logger.Error("db timeout", "duration_ms", time.Since(start).Milliseconds(), "op", "alias_exists")
				} else {
					logger.Error("db alias uniqueness check failed", "error", err, "op", "alias_exists")
				}
				writeError(w, http.StatusInternalServerError, "Internal error")
				return
			}
			if exists == 1 {
				writeJSON(w, http.StatusConflict, map[string]any{"message": "Alias already taken"})
				return
			}

			shortCode = aliasStr
			aliasTaken = aliasStr
			autoGenerated = false
		}

		// Auto-generate code if alias not supplied.
		if shortCode == "" {
			autoGenerated = true
			for attempt := 0; attempt < 15; attempt++ {
				c, err := codegen.GenerateCode()
				if err != nil {
					logger.Error("code generation failed", "error", err)
					writeError(w, http.StatusInternalServerError, "Internal error")
					return
				}

				var exists int
				if err := db.DB.QueryRowContext(ctx, `SELECT EXISTS(SELECT 1 FROM urls WHERE short_code = ? LIMIT 1)`, c).Scan(&exists); err != nil {
					logger.Error("db code collision check failed", "error", err, "op", "collision_check")
					writeError(w, http.StatusInternalServerError, "Internal error")
					return
				}
				if exists == 1 {
					continue // collision -> retry silently
				}
				shortCode = c
				break
			}

			if shortCode == "" {
				logger.Error("code generation failed after retries", "retries", 15)
				writeError(w, http.StatusInternalServerError, "Internal error")
				return
			}
		}

		// Insert link.
		_, err = db.DB.ExecContext(
			ctx,
			`INSERT INTO urls (short_code, long_url, created_by, expires_at, is_active)
			 VALUES (?, ?, ?, ?, ?)`,
			shortCode,
			longURL,
			creator,
			expires,
			isActive,
		)
		if err != nil {
			logger.Error("failed to insert link", "error", err, "short_code", shortCode)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		// Cache (TTL default if no expiry).
		cacheTTLSeconds := cache.TTLSeconds(nullTimeToPtr(expires))
		cache.Set(context.Background(), shortCode, longURL, cacheTTLSeconds)

		creatorLog := ""
		if creator.Valid {
			creatorLog = creator.String
		}
		logger.Info(
			"link created",
			"short_code", shortCode,
			"creator", creatorLog,
			"alias", aliasTaken,
			"auto_generated", autoGenerated,
		)

		shortURL := cfg.AppBaseURL + "/" + shortCode
		var createdBy *string
		if creator.Valid {
			v := creator.String
			createdBy = &v
		}

		writeJSON(w, http.StatusCreated, createLinkResponse{
			ShortCode: shortCode,
			ShortURL:  shortURL,
			LongURL:   longURL,
			ExpiresAt: nullTimeToPtr(expires),
			CreatedBy: createdBy,
		})
	}
}

// ListLinksHandler implements GET /api/links
func ListLinksHandler(cfg *config.Config, logger *slog.Logger) http.HandlerFunc {
	if logger == nil {
		logger = slog.Default()
	}

	return func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), cfg.DBQueryTimeout)
		defer cancel()

		rows, err := db.DB.QueryContext(
			ctx,
			`SELECT u.id, u.short_code, u.long_url, u.created_by, u.created_at, u.expires_at, u.is_active,
			        COALESCE(COUNT(c.id), 0) AS click_count
			 FROM urls u
			 LEFT JOIN clicks c ON c.url_id = u.id
			 GROUP BY u.id
			 ORDER BY u.created_at DESC`,
		)
		if err != nil {
			logger.Error("list links query failed", "error", err)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}
		defer rows.Close()

		links := make([]linkResponse, 0)
		for rows.Next() {
			var m linkModel
			if err := rows.Scan(
				&m.ID,
				&m.ShortCode,
				&m.LongURL,
				&m.CreatedBy,
				&m.CreatedAt,
				&m.ExpiresAt,
				&m.IsActive,
				&m.ClickCount,
			); err != nil {
				logger.Error("list links scan failed", "error", err)
				writeError(w, http.StatusInternalServerError, "Internal error")
				return
			}
			links = append(links, toLinkResponse(m))
		}

		writeJSON(w, http.StatusOK, map[string]any{
			"links": links,
		})
	}
}

// GetLinkHandler implements GET /api/links/{code}
func GetLinkHandler(cfg *config.Config, logger *slog.Logger) http.HandlerFunc {
	if logger == nil {
		logger = slog.Default()
	}

	return func(w http.ResponseWriter, r *http.Request) {
		code := chi.URLParam(r, "code")
		if code == "" {
			writeError(w, http.StatusNotFound, "Link not found")
			return
		}

		ctx, cancel := context.WithTimeout(r.Context(), cfg.DBQueryTimeout)
		defer cancel()

		m, err := getLinkByCodeWithClicks(ctx, code)
		if err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				writeError(w, http.StatusNotFound, "Link not found")
				return
			}
			logger.Error("get link failed", "error", err, "code", code)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		writeJSON(w, http.StatusOK, toLinkResponse(m))
	}
}

// PatchLinkHandler implements PATCH /api/links/{code}
func PatchLinkHandler(cfg *config.Config, logger *slog.Logger) http.HandlerFunc {
	if logger == nil {
		logger = slog.Default()
	}

	return func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		code := chi.URLParam(r, "code")
		if code == "" {
			writeError(w, http.StatusNotFound, "Link not found")
			return
		}

		var raw map[string]json.RawMessage
		if err := json.NewDecoder(r.Body).Decode(&raw); err != nil {
			writeError(w, http.StatusBadRequest, "Invalid JSON body")
			return
		}

		ctx, cancel := context.WithTimeout(r.Context(), cfg.DBQueryTimeout)
		defer cancel()

		existing, err := getLinkByCode(ctx, code)
		if err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				writeError(w, http.StatusNotFound, "Link not found")
				return
			}
			if errors.Is(err, context.DeadlineExceeded) {
				logger.Error("db timeout", "duration_ms", time.Since(start).Milliseconds(), "op", "fetch_existing_link")
			} else {
				logger.Error("fetch existing link failed", "error", err, "code", code)
			}
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		// Apply updates.
		newLongURL := existing.LongURL
		newExpires := existing.ExpiresAt
		newIsActive := existing.IsActive

		if v, ok := raw["long_url"]; ok {
			if string(v) == "null" {
				writeError(w, http.StatusBadRequest, "long_url must not be null")
				return
			}
			var s string
			if err := json.Unmarshal(v, &s); err != nil || strings.TrimSpace(s) == "" {
				writeError(w, http.StatusBadRequest, "long_url must be a non-empty string")
				return
			}
			newLongURL = strings.TrimSpace(s)
		}

		if v, ok := raw["expires_at"]; ok {
			var parsed sql.NullTime
			parsed, err = setExpiresAtFromRaw(v)
			if err != nil {
				writeError(w, http.StatusBadRequest, "expires_at must be RFC3339 timestamp string or null")
				return
			}
			newExpires = parsed
		}

		if v, ok := raw["is_active"]; ok {
			if string(v) == "null" {
				writeError(w, http.StatusBadRequest, "is_active must not be null")
				return
			}
			var b bool
			if err := json.Unmarshal(v, &b); err != nil {
				writeError(w, http.StatusBadRequest, "is_active must be a boolean")
				return
			}
			newIsActive = b
		}

		// Invalidate cache first (required on deactivate/update).
		cache.Delete(context.Background(), code)

		// Update MySQL.
		_, err = db.DB.ExecContext(
			ctx,
			`UPDATE urls SET long_url = ?, expires_at = ?, is_active = ?
			 WHERE short_code = ?`,
			newLongURL,
			newExpires,
			newIsActive,
			code,
		)
		if err != nil {
			logger.Error("patch link update failed", "error", err, "code", code)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		// Re-populate cache if link is active and not already expired.
		if newIsActive {
			now := time.Now().UTC()
			expPtr := nullTimeToPtr(newExpires)
			if expPtr == nil || expPtr.After(now) {
				ttlSeconds := cache.TTLSeconds(expPtr)
				cache.Set(context.Background(), code, newLongURL, ttlSeconds)
			}
		}

		logger.Info(
			"link updated",
			"short_code", code,
			"response_time_ms", time.Since(start).Milliseconds(),
			"is_active", newIsActive,
		)

		writeJSON(w, http.StatusOK, map[string]any{"message": "Link updated"})
	}
}

// DeleteLinkHandler implements DELETE /api/links/{code}
func DeleteLinkHandler(cfg *config.Config, logger *slog.Logger) http.HandlerFunc {
	if logger == nil {
		logger = slog.Default()
	}

	return func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		code := chi.URLParam(r, "code")
		if code == "" {
			writeError(w, http.StatusNotFound, "Link not found")
			return
		}

		ctx, cancel := context.WithTimeout(r.Context(), cfg.DBQueryTimeout)
		defer cancel()

		// Transaction: delete clicks first, then the URL.
		tx, err := db.DB.BeginTx(ctx, nil)
		if err != nil {
			logger.Error("delete begin tx failed", "error", err)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}
		defer func() {
			_ = tx.Rollback()
		}()

		var urlID int64
		err = tx.QueryRowContext(ctx, `SELECT id FROM urls WHERE short_code = ? LIMIT 1`, code).Scan(&urlID)
		if err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				writeError(w, http.StatusNotFound, "Link not found")
				return
			}
			logger.Error("delete fetch url_id failed", "error", err, "code", code)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		if _, err := tx.ExecContext(ctx, `DELETE FROM clicks WHERE url_id = ?`, urlID); err != nil {
			logger.Error("delete clicks failed", "error", err, "url_id", urlID)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}
		if _, err := tx.ExecContext(ctx, `DELETE FROM urls WHERE id = ?`, urlID); err != nil {
			logger.Error("delete urls failed", "error", err, "url_id", urlID)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		if err := tx.Commit(); err != nil {
			logger.Error("delete commit failed", "error", err)
			writeError(w, http.StatusInternalServerError, "Internal error")
			return
		}

		cache.Delete(context.Background(), code)

		logger.Info("link deleted", "short_code", code, "response_time_ms", time.Since(start).Milliseconds())
		writeJSON(w, http.StatusOK, map[string]any{"message": "Link deleted"})
	}
}
