package handler

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"regexp"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/go-chi/chi/v5"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"gitlab.com/vishal101/url-shortener/internal/cache"
	"gitlab.com/vishal101/url-shortener/internal/config"
	"gitlab.com/vishal101/url-shortener/internal/db"
	"gitlab.com/vishal101/url-shortener/internal/middleware"
)

func setupLinksDB(t *testing.T) (sqlmock.Sqlmock, func()) {
	t.Helper()
	cache.DisableRedis()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock: %v", err)
	}
	db.DB = sqlDB
	return mock, func() { _ = sqlDB.Close() }
}

func linksCfg() *config.Config {
	return &config.Config{
		AppBaseURL:     "http://localhost:8080",
		DBQueryTimeout: 3 * time.Second,
		CacheDefaultTTL: 24 * time.Hour,
		APIKeySecret:   "test-key",
	}
}

func testLinksLogger() *slog.Logger {
	return slog.New(slog.NewJSONHandler(io.Discard, nil))
}

type createLinkResp struct {
	ShortCode string     `json:"short_code"`
	ShortURL  string     `json:"short_url"`
	LongURL   string     `json:"long_url"`
	ExpiresAt *time.Time `json:"expires_at"`
	CreatedBy *string    `json:"created_by"`
}

func TestCreateLink_TableDriven(t *testing.T) {
	tests := []struct {
		name       string
		body       string
		setupMock  func(mock sqlmock.Sqlmock)
		wantStatus int
		assertJSON func(t *testing.T, raw []byte)
	}{
		{
			name: "valid creation with created_by",
			body: `{"long_url":"https://xobin.com/careers","created_by":"test@xobin.com"}`,
			setupMock: func(mock sqlmock.Sqlmock) {
				mock.ExpectQuery(regexp.QuoteMeta("SELECT EXISTS(SELECT 1 FROM urls WHERE short_code = ? LIMIT 1)")).
					WillReturnRows(sqlmock.NewRows([]string{"exists"}).AddRow(0))
				mock.ExpectExec(regexp.QuoteMeta("INSERT INTO urls (short_code, long_url, created_by, expires_at, is_active) VALUES (?, ?, ?, ?, ?)")).
					WillReturnResult(sqlmock.NewResult(1, 1))
			},
			wantStatus: http.StatusCreated,
			assertJSON: func(t *testing.T, raw []byte) {
				var out createLinkResp
				require.NoError(t, json.Unmarshal(raw, &out))
				require.NotEmpty(t, out.ShortCode)
				assert.Equal(t, "http://localhost:8080/"+out.ShortCode, out.ShortURL)
				assert.Equal(t, "https://xobin.com/careers", out.LongURL)
				assert.Nil(t, out.ExpiresAt)
				require.NotNil(t, out.CreatedBy)
				assert.Equal(t, "test@xobin.com", *out.CreatedBy)
			},
		},
		{
			name: "custom alias",
			body: `{"long_url":"https://xobin.com/careers","alias":"apply-2025"}`,
			setupMock: func(mock sqlmock.Sqlmock) {
				mock.ExpectQuery(regexp.QuoteMeta("SELECT EXISTS(SELECT 1 FROM urls WHERE short_code = ? LIMIT 1)")).
					WithArgs("apply-2025").
					WillReturnRows(sqlmock.NewRows([]string{"exists"}).AddRow(0))
				mock.ExpectExec(regexp.QuoteMeta("INSERT INTO urls (short_code, long_url, created_by, expires_at, is_active) VALUES (?, ?, ?, ?, ?)")).
					WithArgs("apply-2025", "https://xobin.com/careers", sqlmock.AnyArg(), sql.NullTime{}, true).
					WillReturnResult(sqlmock.NewResult(1, 1))
			},
			wantStatus: http.StatusCreated,
			assertJSON: func(t *testing.T, raw []byte) {
				var out createLinkResp
				require.NoError(t, json.Unmarshal(raw, &out))
				assert.Equal(t, "apply-2025", out.ShortCode)
				assert.Equal(t, "http://localhost:8080/apply-2025", out.ShortURL)
				assert.Equal(t, "https://xobin.com/careers", out.LongURL)
			},
		},
		{
			name: "duplicate alias",
			body: `{"long_url":"https://xobin.com/careers","alias":"apply-2025"}`,
			setupMock: func(mock sqlmock.Sqlmock) {
				mock.ExpectQuery(regexp.QuoteMeta("SELECT EXISTS(SELECT 1 FROM urls WHERE short_code = ? LIMIT 1)")).
					WithArgs("apply-2025").
					WillReturnRows(sqlmock.NewRows([]string{"exists"}).AddRow(1))
			},
			wantStatus: http.StatusConflict,
			assertJSON: func(t *testing.T, raw []byte) {
				var out jsonMessage
				require.NoError(t, json.Unmarshal(raw, &out))
				assert.Equal(t, "Alias already taken", out.Message)
			},
		},
		{
			name: "invalid JSON",
			body: `{bad`,
			setupMock: func(mock sqlmock.Sqlmock) {
				// no DB
			},
			wantStatus: http.StatusBadRequest,
			assertJSON: func(t *testing.T, raw []byte) {
				var out jsonMessage
				require.NoError(t, json.Unmarshal(raw, &out))
				assert.Equal(t, "Invalid JSON body", out.Message)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mock, done := setupLinksDB(t)
			defer done()
			tt.setupMock(mock)

			cfg := linksCfg()
			req := httptest.NewRequest(http.MethodPost, "/api/links", bytes.NewBufferString(tt.body))
			rr := httptest.NewRecorder()
			CreateLinkHandler(cfg, testLinksLogger()).ServeHTTP(rr, req)

			assert.Equal(t, tt.wantStatus, rr.Code)
			tt.assertJSON(t, rr.Body.Bytes())
		})
	}
}

func TestCreateLink_InvalidURLInput_NotStoredInDB(t *testing.T) {
	mock, done := setupLinksDB(t)
	defer done()

	cfg := linksCfg()
	h := CreateLinkHandler(cfg, testLinksLogger())

	cases := []struct {
		name       string
		body       string
		wantStatus int
		wantMsg    string
	}{
		{
			name:       "empty long_url",
			body:       `{"long_url":""}`,
			wantStatus: http.StatusBadRequest,
			wantMsg:    "long_url must be a non-empty string",
		},
		{
			name:       "invalid url short token",
			body:       `{"long_url":"abc"}`,
			wantStatus: http.StatusBadRequest,
			wantMsg:    "long_url must be a valid URL",
		},
		{
			name:       "invalid url not-a-url",
			body:       `{"long_url":"not-a-url"}`,
			wantStatus: http.StatusBadRequest,
			wantMsg:    "long_url must be a valid URL",
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			rr := httptest.NewRecorder()
			req := httptest.NewRequest(http.MethodPost, "/api/links", bytes.NewBufferString(tc.body))

			h.ServeHTTP(rr, req)

			if rr.Code != tc.wantStatus {
				t.Fatalf("status: got %d want %d body=%s", rr.Code, tc.wantStatus, rr.Body.String())
			}

			var out jsonMessage
			require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &out))
			assert.Equal(t, tc.wantMsg, out.Message)

			// No SQL expectations were registered: ensure nothing was written to the DB.
			require.NoError(t, mock.ExpectationsWereMet())
		})
	}
}

func TestCreateLink_MalformedJSONInput_Returns400_NoDBInsert(t *testing.T) {
	tests := []struct {
		name       string
		body       string
		wantStatus int
		wantMsg    string
	}{
		{
			name:       "long_url wrong type number",
			body:       `{"long_url":123}`,
			wantStatus: http.StatusBadRequest,
			wantMsg:    "long_url must be a non-empty string",
		},
		{
			name:       "malformed JSON syntax",
			body:       `{bad`,
			wantStatus: http.StatusBadRequest,
			wantMsg:    "Invalid JSON body",
		},
		{
			name:       "missing opening brace",
			body:       `"long_url":"https://example.com"}`,
			wantStatus: http.StatusBadRequest,
			wantMsg:    "Invalid JSON body",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			mock, done := setupLinksDB(t)
			defer done()

			cfg := linksCfg()
			h := CreateLinkHandler(cfg, testLinksLogger())

			rr := httptest.NewRecorder()
			req := httptest.NewRequest(http.MethodPost, "/api/links", bytes.NewBufferString(tc.body))
			h.ServeHTTP(rr, req)

			assert.Equal(t, tc.wantStatus, rr.Code)

			var out jsonMessage
			require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &out))
			assert.Equal(t, tc.wantMsg, out.Message)

			// Ensure no DB insertion (and no unexpected DB calls) occurred.
			require.NoError(t, mock.ExpectationsWereMet())
		})
	}
}

func TestCreateLink_ShorteningSameURLTwice_ReturnsValidShortCodes(t *testing.T) {
	// This test asserts that shortening the same long URL twice does not crash,
	// and that both responses look valid. The implementation does not include a
	// "reuse by long_url" feature, so typically the codes differ.
	mock, done := setupLinksDB(t)
	defer done()
	mock.MatchExpectationsInOrder(true)

	cfg := linksCfg()
	h := CreateLinkHandler(cfg, testLinksLogger())

	longURL := "https://example.com/careers"

	// First create
	mock.ExpectQuery(regexp.QuoteMeta("SELECT EXISTS(SELECT 1 FROM urls WHERE short_code = ? LIMIT 1)")).
		WithArgs(sqlmock.AnyArg()).
		WillReturnRows(sqlmock.NewRows([]string{"exists"}).AddRow(0))
	mock.ExpectExec(regexp.QuoteMeta("INSERT INTO urls (short_code, long_url, created_by, expires_at, is_active) VALUES (?, ?, ?, ?, ?)")).
		WithArgs(sqlmock.AnyArg(), longURL, sqlmock.AnyArg(), sql.NullTime{}, true).
		WillReturnResult(sqlmock.NewResult(1, 1))

	rr1 := httptest.NewRecorder()
	req1 := httptest.NewRequest(http.MethodPost, "/api/links", bytes.NewBufferString(`{"long_url":`+`"`+longURL+`"`+`}`))
	h.ServeHTTP(rr1, req1)

	require.Equal(t, http.StatusCreated, rr1.Code)
	var out1 createLinkResp
	require.NoError(t, json.Unmarshal(rr1.Body.Bytes(), &out1))
	require.NotEmpty(t, out1.ShortCode)
	assert.Equal(t, cfg.AppBaseURL+"/"+out1.ShortCode, out1.ShortURL)
	assert.Equal(t, longURL, out1.LongURL)

	// Second create
	mock.ExpectQuery(regexp.QuoteMeta("SELECT EXISTS(SELECT 1 FROM urls WHERE short_code = ? LIMIT 1)")).
		WithArgs(sqlmock.AnyArg()).
		WillReturnRows(sqlmock.NewRows([]string{"exists"}).AddRow(0))
	mock.ExpectExec(regexp.QuoteMeta("INSERT INTO urls (short_code, long_url, created_by, expires_at, is_active) VALUES (?, ?, ?, ?, ?)")).
		WithArgs(sqlmock.AnyArg(), longURL, sqlmock.AnyArg(), sql.NullTime{}, true).
		WillReturnResult(sqlmock.NewResult(1, 1))

	rr2 := httptest.NewRecorder()
	req2 := httptest.NewRequest(http.MethodPost, "/api/links", bytes.NewBufferString(`{"long_url":`+`"`+longURL+`"`+`}`))
	h.ServeHTTP(rr2, req2)

	require.Equal(t, http.StatusCreated, rr2.Code)
	var out2 createLinkResp
	require.NoError(t, json.Unmarshal(rr2.Body.Bytes(), &out2))
	require.NotEmpty(t, out2.ShortCode)
	assert.Equal(t, cfg.AppBaseURL+"/"+out2.ShortCode, out2.ShortURL)
	assert.Equal(t, longURL, out2.LongURL)

	// Accept either behavior:
	// - If implementation reuses short codes, codes match.
	// - Otherwise codes differ.
	if out1.ShortCode == out2.ShortCode {
		assert.Equal(t, out1.ShortURL, out2.ShortURL)
	} else {
		assert.NotEqual(t, out1.ShortCode, out2.ShortCode)
	}

	require.NoError(t, mock.ExpectationsWereMet())
}

func TestCreateLink_ShortCodeCollisionRetriesOnce_NoOverwrite(t *testing.T) {
	mock, done := setupLinksDB(t)
	defer done()
	mock.MatchExpectationsInOrder(true)

	cfg := linksCfg()
	h := CreateLinkHandler(cfg, testLinksLogger())

	longURL := "https://example.com/careers"

	// Simulate a collision in the auto-generation loop:
	// 1) First generated short_code already exists -> exists=1
	// 2) Next generated short_code is free -> exists=0
	mock.ExpectQuery(regexp.QuoteMeta("SELECT EXISTS(SELECT 1 FROM urls WHERE short_code = ? LIMIT 1)")).
		WithArgs(sqlmock.AnyArg()).
		WillReturnRows(sqlmock.NewRows([]string{"exists"}).AddRow(1))
	mock.ExpectQuery(regexp.QuoteMeta("SELECT EXISTS(SELECT 1 FROM urls WHERE short_code = ? LIMIT 1)")).
		WithArgs(sqlmock.AnyArg()).
		WillReturnRows(sqlmock.NewRows([]string{"exists"}).AddRow(0))

	// Ensure we only insert once after the collision retry.
	mock.ExpectExec(regexp.QuoteMeta("INSERT INTO urls (short_code, long_url, created_by, expires_at, is_active) VALUES (?, ?, ?, ?, ?)")).
		WithArgs(sqlmock.AnyArg(), longURL, sqlmock.AnyArg(), sql.NullTime{}, true).
		WillReturnResult(sqlmock.NewResult(1, 1))

	rr := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/api/links", bytes.NewBufferString(`{"long_url":`+`"`+longURL+`"`+`}`))
	h.ServeHTTP(rr, req)

	require.Equal(t, http.StatusCreated, rr.Code)

	var out createLinkResp
	require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &out))
	require.NotEmpty(t, out.ShortCode)
	assert.Equal(t, longURL, out.LongURL)

	require.NoError(t, mock.ExpectationsWereMet())
}

func TestCreateLink_APIKey_TableDriven(t *testing.T) {
	tests := []struct {
		name       string
		authHeader string
		wantCode   int
	}{
		{name: "missing", authHeader: "", wantCode: http.StatusUnauthorized},
		{name: "invalid", authHeader: "Bearer wrong", wantCode: http.StatusUnauthorized},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			cache.DisableRedis()
			cfg := linksCfg()
			r := chi.NewRouter()
			r.Use(middleware.RequireAPIKey(cfg, testLinksLogger()))
			r.Post("/api/links", CreateLinkHandler(cfg, testLinksLogger()))

			req := httptest.NewRequest(http.MethodPost, "/api/links", bytes.NewBufferString(`{"long_url":"https://xobin.com"}`))
			if tt.authHeader != "" {
				req.Header.Set("Authorization", tt.authHeader)
			}
			rr := httptest.NewRecorder()
			r.ServeHTTP(rr, req)

			assert.Equal(t, tt.wantCode, rr.Code)
			var out map[string]any
			require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &out))
			assert.Equal(t, "unauthorized", out["error"])
			assert.Equal(t, "Invalid API key", out["message"])
		})
	}
}

func TestPatchDeleteLink_TableDriven(t *testing.T) {
	t.Run("patch success JSON", func(t *testing.T) {
		mock, done := setupLinksDB(t)
		defer done()
		cfg := linksCfg()

		mock.ExpectQuery(regexp.QuoteMeta("SELECT id, short_code, long_url, created_by, created_at, expires_at, is_active FROM urls WHERE short_code = ? LIMIT 1")).
			WithArgs("abc1234").
			WillReturnRows(sqlmock.NewRows([]string{"id", "short_code", "long_url", "created_by", "created_at", "expires_at", "is_active"}).
				AddRow(1, "abc1234", "https://old.com", "test", time.Now(), nil, true))
		mock.ExpectExec(regexp.QuoteMeta("UPDATE urls SET long_url = ?, expires_at = ?, is_active = ? WHERE short_code = ?")).
			WillReturnResult(sqlmock.NewResult(0, 1))

		req := httptest.NewRequest(http.MethodPatch, "/api/links/abc1234", bytes.NewBufferString(`{"long_url":"https://new.com"}`))
		req = addChiURLParam(req, "code", "abc1234")
		rr := httptest.NewRecorder()
		PatchLinkHandler(cfg, testLinksLogger()).ServeHTTP(rr, req)

		assert.Equal(t, http.StatusOK, rr.Code)
		var out jsonMessage
		require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &out))
		assert.Equal(t, "Link updated", out.Message)
	})

	t.Run("delete success JSON", func(t *testing.T) {
		mock, done := setupLinksDB(t)
		defer done()
		cfg := linksCfg()

		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta("SELECT id FROM urls WHERE short_code = ? LIMIT 1")).
			WithArgs("abc1234").
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mock.ExpectExec(regexp.QuoteMeta("DELETE FROM clicks WHERE url_id = ?")).
			WithArgs(int64(1)).
			WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(regexp.QuoteMeta("DELETE FROM urls WHERE id = ?")).
			WithArgs(int64(1)).
			WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		req := httptest.NewRequest(http.MethodDelete, "/api/links/abc1234", nil)
		req = addChiURLParam(req, "code", "abc1234")
		rr := httptest.NewRecorder()
		DeleteLinkHandler(cfg, testLinksLogger()).ServeHTTP(rr, req)

		assert.Equal(t, http.StatusOK, rr.Code)
		var out jsonMessage
		require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &out))
		assert.Equal(t, "Link deleted", out.Message)
	})
}

func addChiURLParam(req *http.Request, key, val string) *http.Request {
	rctx := chi.NewRouteContext()
	rctx.URLParams.Add(key, val)
	return req.WithContext(context.WithValue(req.Context(), chi.RouteCtxKey, rctx))
}
