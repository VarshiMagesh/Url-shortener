package handler

import (
	"context"
	"time"

	"github.com/stretchr/testify/mock"
)

// Mocking requirement support: reusable mock interfaces for DB/Cache behavior.
type DBService interface {
	CountRecentRequests(ctx context.Context, ip, endpoint string) (int64, error)
}

type CacheService interface {
	Get(ctx context.Context, key string) string
	Set(ctx context.Context, key, value string, ttl time.Duration) error
	Delete(ctx context.Context, key string) error
}

type MockDBService struct {
	mock.Mock
}

func (m *MockDBService) CountRecentRequests(ctx context.Context, ip, endpoint string) (int64, error) {
	args := m.Called(ctx, ip, endpoint)
	return args.Get(0).(int64), args.Error(1)
}

type MockCacheService struct {
	mock.Mock
}

func (m *MockCacheService) Get(ctx context.Context, key string) string {
	args := m.Called(ctx, key)
	return args.String(0)
}

func (m *MockCacheService) Set(ctx context.Context, key, value string, ttl time.Duration) error {
	args := m.Called(ctx, key, value, ttl)
	return args.Error(0)
}

func (m *MockCacheService) Delete(ctx context.Context, key string) error {
	args := m.Called(ctx, key)
	return args.Error(0)
}

