package handler

import (
	"context"
	"database/sql"
	"errors"
	"log/slog"
	"net"
	"net/http"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"

	"gitlab.com/vishal101/url-shortener/internal/cache"
	"gitlab.com/vishal101/url-shortener/internal/config"
	"gitlab.com/vishal101/url-shortener/internal/db"
	"gitlab.com/vishal101/url-shortener/internal/utm"
)

func clientIPFromRequest(r *http.Request) string {
	if fwd := r.Header.Get("X-Forwarded-For"); fwd != "" {
		parts := strings.Split(fwd, ",")
		if len(parts) > 0 {
			return strings.TrimSpace(parts[0])
		}
	}
	if realIP := strings.TrimSpace(r.Header.Get("X-Real-IP")); realIP != "" {
		return realIP
	}
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err == nil {
		return host
	}
	return r.RemoteAddr
}

// RedirectHandler implements GET /{code} with 302 redirects.
func RedirectHandler(cfg *config.Config, logger *slog.Logger) http.HandlerFunc {
	if logger == nil {
		logger = slog.Default()
	}

	return func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		code := chi.URLParam(r, "code")

		if code == "" {
			writeError(w, http.StatusNotFound, "Link not found")
			return
		}

		ctx := r.Context()

		longURL := cache.Get(ctx, code)
		if longURL != "" {
			// Cache hit -> redirect immediately.
			ip := clientIPFromRequest(r)
			referrer := r.Header.Get("Referer")
			userAgent := r.Header.Get("User-Agent")

			w.Header().Set("Location", longURL)
			w.WriteHeader(http.StatusFound) // 302

			go func() {
				// We only cached long_url; resolve url_id for click logging.
				urlID := lookupURLIDForUTM(code, cfg)
				if urlID <= 0 {
					return
				}
				utm.LogClick(db.DB, cfg, ip, referrer, userAgent, urlID)
			}()

			logger.Info(
				"redirect served",
				"short_code", code,
				"cache_hit", true,
				"response_time_ms", time.Since(start).Milliseconds(),
			)
			return
		}

		// Cache miss -> query MySQL.
		logger.Info("redirect cache miss", "short_code", code)

		dbCtx, cancel := context.WithTimeout(ctx, cfg.DBQueryTimeout)
		defer cancel()

		var (
			urlID     int64
			longURLDB string
			expiresAt sql.NullTime
			isActive  bool
		)

		err := db.DB.QueryRowContext(
			dbCtx,
			`SELECT id, long_url, expires_at, is_active
			 FROM urls
			 WHERE short_code = ?
			 LIMIT 1`,
			code,
		).Scan(&urlID, &longURLDB, &expiresAt, &isActive)

		elapsed := time.Since(start)
		if err != nil {
			if errors.Is(err, context.DeadlineExceeded) {
				logger.Error("db timeout", "duration_ms", elapsed.Milliseconds(), "short_code", code, "op", "redirect_lookup")
			} else {
				logger.Error("db lookup failed", "error", err, "short_code", code, "op", "redirect_lookup")
			}

			if errors.Is(err, sql.ErrNoRows) {
				writeError(w, http.StatusNotFound, "Link not found")
			} else {
				writeError(w, http.StatusInternalServerError, "Internal error")
			}
			return
		}

		now := time.Now().UTC()
		if !isActive || (expiresAt.Valid && !expiresAt.Time.UTC().After(now)) {
			writeJSON(w, http.StatusGone, map[string]any{"message": "Link expired or inactive"})
			logger.Info(
				"redirect blocked",
				"short_code", code,
				"reason", "expired_or_inactive",
				"response_time_ms", elapsed.Milliseconds(),
			)
			return
		}

		var expiresPtr *time.Time
		if expiresAt.Valid {
			t := expiresAt.Time.UTC()
			expiresPtr = &t
		}
		ttlSeconds := cache.TTLSeconds(expiresPtr)
		cache.Set(ctx, code, longURLDB, ttlSeconds)

		// Send redirect (302) and then log UTM asynchronously.
		w.Header().Set("Location", longURLDB)
		w.WriteHeader(http.StatusFound)

		ip := clientIPFromRequest(r)
		referrer := r.Header.Get("Referer")
		userAgent := r.Header.Get("User-Agent")
		go utm.LogClick(db.DB, cfg, ip, referrer, userAgent, urlID)

		logger.Info(
			"redirect served",
			"short_code", code,
			"cache_hit", false,
			"response_time_ms", elapsed.Milliseconds(),
		)
	}
}

func lookupURLIDForUTM(code string, cfg *config.Config) int64 {
	if cfg == nil || db.DB == nil {
		return 0
	}

	start := time.Now()
	ctx, cancel := context.WithTimeout(context.Background(), cfg.DBQueryTimeout)
	defer cancel()

	var urlID int64
	err := db.DB.QueryRowContext(
		ctx,
		`SELECT id FROM urls WHERE short_code = ? LIMIT 1`,
		code,
	).Scan(&urlID)
	if err != nil {
		if errors.Is(err, context.DeadlineExceeded) {
			slog.Error("db timeout", "duration_ms", time.Since(start).Milliseconds(), "op", "utm_url_id_lookup", "short_code", code, "error", err)
		} else {
			slog.Error("utm url_id lookup failed", "short_code", code, "error", err)
		}
		return 0
	}
	return urlID
}

