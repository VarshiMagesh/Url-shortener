package handler

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net"
	"net/http"
	"net/http/httptest"
	"runtime"
	"strconv"
	"sync"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/alicebob/miniredis/v2"
	"github.com/go-chi/chi/v5"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"gitlab.com/vishal101/url-shortener/internal/cache"
	"gitlab.com/vishal101/url-shortener/internal/config"
	"gitlab.com/vishal101/url-shortener/internal/db"
)

func setupRedirectDB(t *testing.T) (sqlmock.Sqlmock, func()) {
	t.Helper()
	cache.DisableRedis()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock: %v", err)
	}
	db.DB = sqlDB
	return mock, func() { _ = sqlDB.Close() }
}

// waitHandlerAsyncSQL waits for sqlmock expectations including async goroutines (bounded).
func waitHandlerAsyncSQL(t *testing.T, mock sqlmock.Sqlmock, maxWait time.Duration) {
	t.Helper()
	deadline := time.Now().Add(maxWait)
	for time.Now().Before(deadline) {
		if err := mock.ExpectationsWereMet(); err == nil {
			return
		}
		time.Sleep(5 * time.Millisecond)
		runtime.Gosched() // keep the scheduler fair while waiting
	}
	require.NoError(t, mock.ExpectationsWereMet())
}

func fakeIPLookupServer(t *testing.T) string {
	t.Helper()
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"status":"success","country":"Testland"}`))
	}))
	t.Cleanup(ts.Close)
	return ts.URL + "/"
}

func newRedirectConfig() *config.Config {
	return &config.Config{
		DBQueryTimeout:      3 * time.Second,
		CacheDefaultTTL:    24 * time.Hour,
		RedisSocketTimeout: 3 * time.Second,
		DBMaxOpenConns:     10,
		IPLookupTimeout:    2 * time.Second,
		IPLookupBaseURL:    "http://127.0.0.1:9/unused/", // overridden per test when needed
	}
}

func serveRedirect(code string, h http.HandlerFunc) *httptest.ResponseRecorder {
	rctx := chi.NewRouteContext()
	rctx.URLParams.Add("code", code)
	req := httptest.NewRequest(http.MethodGet, "/"+code, nil)
	req = req.WithContext(contextWithRoute(req.Context(), rctx))
	rr := httptest.NewRecorder()
	h.ServeHTTP(rr, req)
	return rr
}

func serveRedirectWithHeaders(code string, h http.HandlerFunc, xForwardedFor string) *httptest.ResponseRecorder {
	rctx := chi.NewRouteContext()
	rctx.URLParams.Add("code", code)
	req := httptest.NewRequest(http.MethodGet, "/"+code, nil)
	if xForwardedFor != "" {
		req.Header.Set("X-Forwarded-For", xForwardedFor)
	}
	req = req.WithContext(contextWithRoute(req.Context(), rctx))
	rr := httptest.NewRecorder()
	h.ServeHTTP(rr, req)
	return rr
}

func contextWithRoute(ctx context.Context, rctx *chi.Context) context.Context {
	return context.WithValue(ctx, chi.RouteCtxKey, rctx)
}

func TestRedirect_TableDriven(t *testing.T) {
	tests := []struct {
		name           string
		code           string
		setupMock      func(mock sqlmock.Sqlmock, code string)
		assertResponse func(t *testing.T, rr *httptest.ResponseRecorder)
		waitAsync      bool
	}{
		{
			name: "cache miss 302 active link",
			code: "abc1234",
			setupMock: func(mock sqlmock.Sqlmock, code string) {
				mock.ExpectQuery(`SELECT id, long_url, expires_at, is_active FROM urls`).
					WithArgs(code).
					WillReturnRows(sqlmock.NewRows([]string{"id", "long_url", "expires_at", "is_active"}).
						AddRow(1, "https://example.com", nil, true))
				mock.ExpectExec(`INSERT INTO clicks`).
					WithArgs(int64(1), "", "", sqlmock.AnyArg(), sqlmock.AnyArg()).
					WillReturnResult(sqlmock.NewResult(1, 1))
			},
			assertResponse: func(t *testing.T, rr *httptest.ResponseRecorder) {
				assert.Equal(t, http.StatusFound, rr.Code)
				assert.Equal(t, "https://example.com", rr.Header().Get("Location"))
			},
			waitAsync: true,
		},
		{
			name: "not found",
			code: "missing",
			setupMock: func(mock sqlmock.Sqlmock, code string) {
				mock.ExpectQuery(`SELECT id, long_url, expires_at, is_active FROM urls`).
					WithArgs(code).
					WillReturnError(sql.ErrNoRows)
			},
			assertResponse: func(t *testing.T, rr *httptest.ResponseRecorder) {
				assert.Equal(t, http.StatusNotFound, rr.Code)
				var body map[string]any
				require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &body))
				assert.Len(t, body, 1)
				assert.Equal(t, "Link not found", body["message"])
			},
			waitAsync: false,
		},
		{
			name: "expired 410",
			code: "expired1",
			setupMock: func(mock sqlmock.Sqlmock, code string) {
				expired := time.Now().Add(-1 * time.Hour)
				mock.ExpectQuery(`SELECT id, long_url, expires_at, is_active FROM urls`).
					WithArgs(code).
					WillReturnRows(sqlmock.NewRows([]string{"id", "long_url", "expires_at", "is_active"}).
						AddRow(7, "https://example.com/x", expired, true))
			},
			assertResponse: func(t *testing.T, rr *httptest.ResponseRecorder) {
				assert.Equal(t, http.StatusGone, rr.Code)
				var body map[string]any
				require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &body))
				assert.Len(t, body, 1)
				assert.Equal(t, "Link expired or inactive", body["message"])
			},
			waitAsync: false,
		},
		{
			name: "inactive 410",
			code: "inactive1",
			setupMock: func(mock sqlmock.Sqlmock, code string) {
				mock.ExpectQuery(`SELECT id, long_url, expires_at, is_active FROM urls`).
					WithArgs(code).
					WillReturnRows(sqlmock.NewRows([]string{"id", "long_url", "expires_at", "is_active"}).
						AddRow(8, "https://example.com/x", nil, false))
			},
			assertResponse: func(t *testing.T, rr *httptest.ResponseRecorder) {
				assert.Equal(t, http.StatusGone, rr.Code)
				var body map[string]any
				require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &body))
				assert.Len(t, body, 1)
				assert.Equal(t, "Link expired or inactive", body["message"])
			},
			waitAsync: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mock, done := setupRedirectDB(t)
			defer done()

			cfg := newRedirectConfig()
			cfg.IPLookupBaseURL = fakeIPLookupServer(t)
			logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

			tt.setupMock(mock, tt.code)

			rr := serveRedirect(tt.code, RedirectHandler(cfg, logger))
			tt.assertResponse(t, rr)

			if tt.waitAsync {
				waitHandlerAsyncSQL(t, mock, 2*time.Second)
			} else {
				require.NoError(t, mock.ExpectationsWereMet())
			}
		})
	}
}

func TestRedirectCacheHitNoDBQueryForMainRow(t *testing.T) {
	mock, done := setupRedirectDB(t)
	defer done()
	cfg := newRedirectConfig()
	cfg.IPLookupBaseURL = fakeIPLookupServer(t)
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

	mr, err := miniredis.Run()
	require.NoError(t, err)
	defer mr.Close()
	cfg.RedisHost = "127.0.0.1"
	cfg.RedisPort = mustPort(t, mr.Addr())
	require.NoError(t, cache.InitRedis(cfg, logger))
	require.NoError(t, mr.Set("cachehit1", "https://cached.example"))

	mock.ExpectQuery(`SELECT id FROM urls`).WithArgs("cachehit1").
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(42))
	mock.ExpectExec(`INSERT INTO clicks`).
		WithArgs(int64(42), "", "", sqlmock.AnyArg(), sqlmock.AnyArg()).
		WillReturnResult(sqlmock.NewResult(1, 1))

	rr := serveRedirect("cachehit1", RedirectHandler(cfg, logger))
	assert.Equal(t, http.StatusFound, rr.Code)
	assert.Equal(t, "https://cached.example", rr.Header().Get("Location"))

	// Must not expect the main "long_url" SELECT for cache hits.
	waitHandlerAsyncSQL(t, mock, 2*time.Second)
}

func TestRedirectNeverUses301(t *testing.T) {
	mock, done := setupRedirectDB(t)
	defer done()
	cfg := newRedirectConfig()
	cfg.IPLookupBaseURL = fakeIPLookupServer(t)
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

	mock.ExpectQuery(`SELECT id, long_url, expires_at, is_active FROM urls`).
		WithArgs("perm").
		WillReturnRows(sqlmock.NewRows([]string{"id", "long_url", "expires_at", "is_active"}).
			AddRow(1, "https://example.com", nil, true))
	mock.ExpectExec(`INSERT INTO clicks`).
		WithArgs(int64(1), "", "", sqlmock.AnyArg(), sqlmock.AnyArg()).
		WillReturnResult(sqlmock.NewResult(1, 1))

	rr := serveRedirect("perm", RedirectHandler(cfg, logger))
	assert.NotEqual(t, http.StatusMovedPermanently, rr.Code)
	assert.Equal(t, http.StatusFound, rr.Code)
	waitHandlerAsyncSQL(t, mock, 2*time.Second)
}

func TestRedirectAsyncClickInsertDoesNotBlockResponse(t *testing.T) {
	mock, done := setupRedirectDB(t)
	defer done()
	cfg := newRedirectConfig()
	cfg.IPLookupBaseURL = fakeIPLookupServer(t)
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

	mock.ExpectQuery(`SELECT id, long_url, expires_at, is_active FROM urls`).
		WithArgs("slowutm").
		WillReturnRows(sqlmock.NewRows([]string{"id", "long_url", "expires_at", "is_active"}).
			AddRow(99, "https://slow.example", nil, true))
	mock.ExpectExec(`INSERT INTO clicks`).
		WithArgs(int64(99), "", "", sqlmock.AnyArg(), sqlmock.AnyArg()).
		WillDelayFor(500 * time.Millisecond).
		WillReturnResult(sqlmock.NewResult(1, 1))

	rr := serveRedirect("slowutm", RedirectHandler(cfg, logger))

	assert.Equal(t, http.StatusFound, rr.Code)
	// The insert is done asynchronously. With a delayed INSERT expectation,
	// it should not have completed by the time ServeHTTP returns.
	assert.Error(t, mock.ExpectationsWereMet(), "async click INSERT must still be pending")
	waitHandlerAsyncSQL(t, mock, 2*time.Second)
}

func TestRedirectConcurrentRequests_TableDriven(t *testing.T) {
	type tc struct {
		name     string
		cacheHit bool
		n        int
	}

	tests := []tc{
		{name: "cache hit concurrent redirects", cacheHit: true, n: 12},
		{name: "cache miss concurrent redirects", cacheHit: false, n: 8},
	}

	const ip = "203.0.113.5"
	const longURLBase = "https://concurrent.example/"

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mock, done := setupRedirectDB(t)
			defer done()
			mock.MatchExpectationsInOrder(false)

			cfg := newRedirectConfig()
			cfg.IPLookupBaseURL = fakeIPLookupServer(t)
			logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

			var mr *miniredis.Miniredis
			if tt.cacheHit {
				var err error
				mr, err = miniredis.Run()
				require.NoError(t, err)
				t.Cleanup(mr.Close)

				cfg.RedisHost = "127.0.0.1"
				cfg.RedisPort = mustPort(t, mr.Addr())
				require.NoError(t, cache.InitRedis(cfg, logger))
			}

			h := RedirectHandler(cfg, logger)

			type res struct {
				i        int
				code     string
				status   int
				location string
			}
			results := make(chan res, tt.n)

			var wg sync.WaitGroup
			wg.Add(tt.n)

			for i := 0; i < tt.n; i++ {
				i := i
				code := fmt.Sprintf("con%d", i)
				urlID := int64(i + 1)
				longURL := longURLBase + code

				if tt.cacheHit {
					require.NoError(t, mr.Set(code, longURL))
					mock.ExpectQuery(`SELECT id FROM urls`).
						WithArgs(code).
						WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(urlID))
					mock.ExpectExec(`INSERT INTO clicks`).
						WithArgs(urlID, "", "", "Testland", ip).
						WillReturnResult(sqlmock.NewResult(1, 1))
				} else {
					mock.ExpectQuery(`SELECT id, long_url, expires_at, is_active FROM urls`).
						WithArgs(code).
						WillReturnRows(sqlmock.NewRows([]string{"id", "long_url", "expires_at", "is_active"}).
							AddRow(urlID, longURL, nil, true))
					mock.ExpectExec(`INSERT INTO clicks`).
						WithArgs(urlID, "", "", "Testland", ip).
						WillReturnResult(sqlmock.NewResult(1, 1))
				}

				go func() {
					defer wg.Done()
					rr := serveRedirectWithHeaders(code, h, ip)
					results <- res{i: i, code: code, status: rr.Code, location: rr.Header().Get("Location")}
				}()
			}

			wg.Wait()
			close(results)

			for r := range results {
				assert.Equal(t, http.StatusFound, r.status, "code %s", r.code)
				assert.Equal(t, longURLBase+r.code, r.location)
			}

			waitHandlerAsyncSQL(t, mock, 3*time.Second)
		})
	}
}

func TestRedirect_NonExistentCode_Returns404_NoPanic(t *testing.T) {
	mock, done := setupRedirectDB(t)
	defer done()

	cfg := newRedirectConfig()
	cfg.IPLookupBaseURL = fakeIPLookupServer(t)
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

	mock.ExpectQuery(`SELECT id, long_url, expires_at, is_active FROM urls`).
		WithArgs("missing-code").
		WillReturnError(sql.ErrNoRows)

	rr := (*httptest.ResponseRecorder)(nil)
	func() {
		defer func() {
			if r := recover(); r != nil {
				t.Fatalf("handler panicked: %v", r)
			}
		}()
		rr = serveRedirect("missing-code", RedirectHandler(cfg, logger))
	}()

	assert.NotNil(t, rr)
	assert.Equal(t, http.StatusNotFound, rr.Code)

	var body map[string]any
	require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &body))
	assert.Len(t, body, 1)
	assert.Equal(t, "Link not found", body["message"])

	require.NoError(t, mock.ExpectationsWereMet())
}

func TestRedirect_EmptyShortCode_Returns404_NoCacheOrDBAccess(t *testing.T) {
	mock, done := setupRedirectDB(t)
	defer done()

	cfg := newRedirectConfig()
	cfg.IPLookupBaseURL = fakeIPLookupServer(t)
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

	rr := serveRedirect("", RedirectHandler(cfg, logger))
	assert.Equal(t, http.StatusNotFound, rr.Code)

	var body map[string]any
	require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &body))
	assert.Len(t, body, 1)
	assert.Equal(t, "Link not found", body["message"])

	// Ensure early validation path did not touch DB.
	require.NoError(t, mock.ExpectationsWereMet())
}

func TestRedirect_CacheFailureFallbackToDB(t *testing.T) {
	// Cache miss should still succeed even if Redis is "unavailable".
	mock, done := setupRedirectDB(t)
	defer done()

	cfg := newRedirectConfig()
	cfg.IPLookupBaseURL = fakeIPLookupServer(t)
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

	mock.ExpectQuery(`SELECT id, long_url, expires_at, is_active FROM urls`).
		WithArgs("cachefail").
		WillReturnRows(sqlmock.NewRows([]string{"id", "long_url", "expires_at", "is_active"}).
			AddRow(123, "https://db.example/cachefail", nil, true))

	// utm.LogClick is executed asynchronously; validate via async expectation draining.
	// In this test we provide X-Forwarded-For so the fake IP lookup returns deterministic "Testland".
	ip := "203.0.113.77"
	mock.ExpectExec(`INSERT INTO clicks`).
		WithArgs(int64(123), "", "", "Testland", ip).
		WillReturnResult(sqlmock.NewResult(1, 1))

	rr := serveRedirectWithHeaders("cachefail", RedirectHandler(cfg, logger), ip)
	assert.Equal(t, http.StatusFound, rr.Code)
	assert.Equal(t, "https://db.example/cachefail", rr.Header().Get("Location"))

	waitHandlerAsyncSQL(t, mock, 2*time.Second)
}

func mustPort(t *testing.T, addr string) int {
	t.Helper()
	host, port, err := net.SplitHostPort(addr)
	_ = host
	if err != nil {
		t.Fatalf("split host port: %v", err)
	}
	p, err := strconv.Atoi(port)
	if err != nil {
		t.Fatalf("atoi port: %v", err)
	}
	return p
}
