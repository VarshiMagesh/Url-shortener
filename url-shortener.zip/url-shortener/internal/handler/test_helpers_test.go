package handler

import (
	"io"
	"log/slog"
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"

	"gitlab.com/vishal101/url-shortener/internal/config"
	"gitlab.com/vishal101/url-shortener/internal/middleware"
)

func testConfig() *config.Config {
	return &config.Config{
		AppBaseURL: "http://localhost:8080",
		APIKeySecret: "test-key",
		DBQueryTimeout: 3 * time.Second,
		CacheDefaultTTL: 24 * time.Hour,
		RateLimitRedirectPerMinute: 300,
		RateLimitAPILinksPostPerMinute: 60,
		RateLimitAPIDefaultPerMinute: 100,
	}
}

// jsonMessage is used for handlers that return `{"message":"..."}`.
type jsonMessage struct {
	Message string `json:"message"`
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewJSONHandler(io.Discard, nil))
}

// SetupRouter is a reusable helper for handler integration tests.
func SetupRouter(cfg *config.Config) http.Handler {
	logger := testLogger()
	r := chi.NewRouter()

	r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelRedirect)).
		Get("/{code}", RedirectHandler(cfg, logger))

	r.Route("/api", func(r chi.Router) {
		r.Use(middleware.RequireAPIKey(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelCreate)).
			Post("/links", CreateLinkHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Get("/links", ListLinksHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Get("/links/{code}", GetLinkHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Patch("/links/{code}", PatchLinkHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Delete("/links/{code}", DeleteLinkHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Get("/links/{code}/analytics", LinkAnalyticsHandler(cfg, logger))

		r.With(middleware.RateLimitMiddleware(cfg, logger, middleware.LevelDefault)).
			Get("/analytics", OverallAnalyticsHandler(cfg, logger))
	})
	return r
}

