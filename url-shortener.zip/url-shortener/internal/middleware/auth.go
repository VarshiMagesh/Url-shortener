package middleware

import (
	"crypto/subtle"
	"log/slog"
	"net/http"
	"strings"
	"time"

	"gitlab.com/vishal101/url-shortener/internal/config"
)

// RequireAPIKey validates the Authorization header using a constant-time comparison.
// Header format: `Authorization: Bearer <key>`
func RequireAPIKey(cfg *config.Config, logger *slog.Logger) func(http.Handler) http.Handler {
	if logger == nil {
		logger = slog.Default()
	}

	secret := []byte(cfg.APIKeySecret)
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			ip := clientIP(r)

			authHeader := r.Header.Get("Authorization")
			if authHeader == "" {
				logger.Warn("api key missing", "ip", ip, "timestamp", time.Now().UTC().Format(time.RFC3339Nano), "path", r.URL.Path)
				writeJSON(w, http.StatusUnauthorized, map[string]any{
					"error":   "unauthorized",
					"message": "Invalid API key",
				})
				return
			}

			parts := strings.SplitN(authHeader, " ", 2)
			if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") {
				logger.Warn("api key invalid format", "ip", ip, "timestamp", time.Now().UTC().Format(time.RFC3339Nano), "path", r.URL.Path)
				writeJSON(w, http.StatusUnauthorized, map[string]any{
					"error":   "unauthorized",
					"message": "Invalid API key",
				})
				return
			}

			token := parts[1]
			ok := constantTimeBearerMatch(secret, []byte(token))
			if !ok {
				logger.Warn("api key rejected", "ip", ip, "timestamp", time.Now().UTC().Format(time.RFC3339Nano), "path", r.URL.Path)
				writeJSON(w, http.StatusUnauthorized, map[string]any{
					"error":   "unauthorized",
					"message": "Invalid API key",
				})
				return
			}

			next.ServeHTTP(w, r)
		})
	}
}

func constantTimeBearerMatch(secret []byte, provided []byte) bool {
	if len(provided) != len(secret) {
		return false
	}
	return subtle.ConstantTimeCompare(provided, secret) == 1
}

