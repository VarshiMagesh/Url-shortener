package middleware

import (
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"gitlab.com/vishal101/url-shortener/internal/config"
)

type apiKeyErrBody struct {
	Error   string `json:"error"`
	Message string `json:"message"`
}

func TestRequireAPIKey_TableDriven(t *testing.T) {
	cfg := &config.Config{APIKeySecret: "secret-key"}
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

	tests := []struct {
		name           string
		authHeader     string
		wantStatus     int
		wantNextCalled bool
		validateBody   func(t *testing.T, body string)
	}{
		{
			name:           "valid key passes",
			authHeader:     "Bearer secret-key",
			wantStatus:     http.StatusOK,
			wantNextCalled: true,
			validateBody:   nil,
		},
		{
			name:           "missing header",
			authHeader:     "",
			wantStatus:     http.StatusUnauthorized,
			wantNextCalled: false,
			validateBody: func(t *testing.T, body string) {
				t.Helper()
				var out apiKeyErrBody
				var raw map[string]any
				require.NoError(t, json.Unmarshal([]byte(body), &out))
				require.NoError(t, json.Unmarshal([]byte(body), &raw))
				assert.Len(t, raw, 2)
				assert.Equal(t, "unauthorized", out.Error)
				assert.Equal(t, "Invalid API key", out.Message)
			},
		},
		{
			name:           "invalid token",
			authHeader:     "Bearer wrong",
			wantStatus:     http.StatusUnauthorized,
			wantNextCalled: false,
			validateBody: func(t *testing.T, body string) {
				t.Helper()
				var out apiKeyErrBody
				var raw map[string]any
				require.NoError(t, json.Unmarshal([]byte(body), &out))
				require.NoError(t, json.Unmarshal([]byte(body), &raw))
				assert.Len(t, raw, 2)
				assert.Equal(t, "unauthorized", out.Error)
				assert.Equal(t, "Invalid API key", out.Message)
			},
		},
		{
			name:           "malformed scheme",
			authHeader:     "Basic secret-key",
			wantStatus:     http.StatusUnauthorized,
			wantNextCalled: false,
			validateBody: func(t *testing.T, body string) {
				t.Helper()
				var out apiKeyErrBody
				var raw map[string]any
				require.NoError(t, json.Unmarshal([]byte(body), &out))
				require.NoError(t, json.Unmarshal([]byte(body), &raw))
				assert.Len(t, raw, 2)
				assert.Equal(t, "unauthorized", out.Error)
				assert.Equal(t, "Invalid API key", out.Message)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			nextCalled := false
			next := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				nextCalled = true
				w.WriteHeader(http.StatusOK)
			})
			h := RequireAPIKey(cfg, logger)(next)

			req := httptest.NewRequest(http.MethodGet, "/api/links", nil)
			if tt.authHeader != "" {
				req.Header.Set("Authorization", tt.authHeader)
			}
			rr := httptest.NewRecorder()
			h.ServeHTTP(rr, req)

			assert.Equal(t, tt.wantStatus, rr.Code)
			assert.Equal(t, tt.wantNextCalled, nextCalled)
			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.String())
			}
		})
	}
}

