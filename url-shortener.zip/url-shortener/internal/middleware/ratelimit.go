package middleware

import (
	"context"
	"log/slog"
	"net/http"

	"gitlab.com/vishal101/url-shortener/internal/config"
	"gitlab.com/vishal101/url-shortener/internal/db"
)

type RateLimitLevel int

const (
	LevelRedirect RateLimitLevel = iota
	LevelCreate
	LevelDefault
)

func RateLimitMiddleware(cfg *config.Config, logger *slog.Logger, level RateLimitLevel) func(http.Handler) http.Handler {
	if logger == nil {
		logger = slog.Default()
	}

	var perMinute int
	switch level {
	case LevelRedirect:
		perMinute = cfg.RateLimitRedirectPerMinute
	case LevelCreate:
		perMinute = cfg.RateLimitAPILinksPostPerMinute
	default:
		perMinute = cfg.RateLimitAPIDefaultPerMinute
	}

	if perMinute <= 0 {
		perMinute = 60
	}

	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if db.DB == nil {
				logger.Error("rate limiting unavailable: db not initialized")
				writeJSON(w, http.StatusInternalServerError, map[string]any{
					"error":   "Internal Server Error",
					"message": "Internal error",
				})
				return
			}

			ip := clientIP(r)
			endpoint := r.URL.Path
			method := r.Method

			// BEFORE processing: count requests in the last 60 seconds for this IP + endpoint.
			countCtx, cancelCount := context.WithTimeout(r.Context(), cfg.DBQueryTimeout)
			var recentCount int64
			err := db.DB.QueryRowContext(
				countCtx,
				`SELECT COUNT(*) FROM request_logs 
				 WHERE ip_address = ? 
				   AND endpoint = ?
				   AND requested_at >= (UTC_TIMESTAMP() - INTERVAL 60 SECOND)`,
				ip,
				endpoint,
			).Scan(&recentCount)
			cancelCount()
			if err != nil {
				logger.Error("rate limit count query failed", "ip", ip, "endpoint", endpoint, "method", method, "error", err)
				writeJSON(w, http.StatusInternalServerError, map[string]any{
					"error":   "Internal Server Error",
					"message": "Internal error",
				})
				return
			}

			if recentCount >= int64(perMinute) {
				logger.Warn("rate limit breach", "ip", ip, "endpoint", endpoint, "method", method, "count", recentCount, "limit", perMinute)
				writeJSON(w, http.StatusTooManyRequests, map[string]any{
					"error":   "Too Many Requests",
					"message": "Rate limit exceeded. Try again in a moment.",
				})
				return
			}

			rr := &statusRecorder{ResponseWriter: w, statusCode: http.StatusOK}
			next.ServeHTTP(rr, r)

			// AFTER processing: async insert into request_logs.
			go func(ipAddr, ep, m string, status int) {
				insertCtx, cancelInsert := context.WithTimeout(context.Background(), cfg.DBQueryTimeout)
				defer cancelInsert()

				_, insertErr := db.DB.ExecContext(
					insertCtx,
					`INSERT INTO request_logs (ip_address, endpoint, method, status_code, requested_at)
					 VALUES (?, ?, ?, ?, NOW())`,
					ipAddr,
					ep,
					m,
					status,
				)
				if insertErr != nil {
					logger.Warn("request_logs insert failed", "ip", ipAddr, "endpoint", ep, "method", m, "status_code", status, "error", insertErr)
				}
			}(ip, endpoint, method, rr.statusCode)
		})
	}
}

type statusRecorder struct {
	http.ResponseWriter
	statusCode int
}

func (r *statusRecorder) WriteHeader(code int) {
	r.statusCode = code
	r.ResponseWriter.WriteHeader(code)
}

