package middleware

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"runtime"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"gitlab.com/vishal101/url-shortener/internal/config"
	"gitlab.com/vishal101/url-shortener/internal/db"
)

func setupRateLimitDB(t *testing.T) (sqlmock.Sqlmock, func()) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock: %v", err)
	}
	db.DB = sqlDB
	return mock, func() {
		_ = sqlDB.Close()
	}
}

// waitRateLimitAsyncMocks drains goroutine expectations (bounded, no arbitrary long sleep).
func waitRateLimitAsyncMocks(t *testing.T, mock sqlmock.Sqlmock, maxWait time.Duration) {
	t.Helper()
	deadline := time.Now().Add(maxWait)
	for time.Now().Before(deadline) {
		if err := mock.ExpectationsWereMet(); err == nil {
			return
		}
		time.Sleep(5 * time.Millisecond)
		runtime.Gosched() // keep the scheduler fair while waiting
	}
	require.NoError(t, mock.ExpectationsWereMet())
}

func TestRateLimitMiddleware_TableDrivenBoundaries(t *testing.T) {
	tests := []struct {
		name        string
		limit       int
		recentCount int64
		wantStatus  int
		expectExec  bool
	}{
		{
			name:        "under limit last allowed slot",
			limit:       5,
			recentCount: 4,
			wantStatus:  http.StatusCreated,
			expectExec:  true,
		},
		{
			name:        "exactly at limit blocks",
			limit:       5,
			recentCount: 5,
			wantStatus:  http.StatusTooManyRequests,
			expectExec:  false,
		},
		{
			name:        "zero recent always allowed when limit positive",
			limit:       100,
			recentCount: 0,
			wantStatus:  http.StatusCreated,
			expectExec:  true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mock, done := setupRateLimitDB(t)
			defer done()

			cfg := &config.Config{
				DBQueryTimeout:                 3 * time.Second,
				RateLimitRedirectPerMinute:     tt.limit,
				RateLimitAPILinksPostPerMinute: tt.limit,
				RateLimitAPIDefaultPerMinute:   tt.limit,
			}
			logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

			mock.ExpectQuery(`SELECT COUNT\(\*\) FROM request_logs`).
				WithArgs("192.168.1.1", "/r").
				WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(tt.recentCount))

			if tt.expectExec {
				mock.ExpectExec(`INSERT INTO request_logs`).
					WithArgs("192.168.1.1", "/r", "GET", http.StatusCreated).
					WillReturnResult(sqlmock.NewResult(1, 1))
			}

			next := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(http.StatusCreated)
			})
			h := RateLimitMiddleware(cfg, logger, LevelDefault)(next)

			req := httptest.NewRequest(http.MethodGet, "/r", nil)
			req.Header.Set("X-Forwarded-For", "192.168.1.1")
			rr := httptest.NewRecorder()
			h.ServeHTTP(rr, req)

			assert.Equal(t, tt.wantStatus, rr.Code)

			if tt.wantStatus == http.StatusTooManyRequests {
				var body map[string]any
				require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &body))
				assert.Len(t, body, 2)
				assert.Equal(t, "Too Many Requests", body["error"])
				assert.Equal(t, "Rate limit exceeded. Try again in a moment.", body["message"])
				require.NoError(t, mock.ExpectationsWereMet())
				return
			}

			waitRateLimitAsyncMocks(t, mock, 1*time.Second)
		})
	}
}

func TestRateLimitMiddleware_BoundaryExactLimitByLevel(t *testing.T) {
	type tc struct {
		name        string
		level       RateLimitLevel
		limit       int
		recentCount int64
		wantStatus  int
		expectExec  bool
	}

	tests := []tc{
		{
			name:        "redirect under limit allowed",
			level:       LevelRedirect,
			limit:       5,
			recentCount: 4,
			wantStatus:  http.StatusCreated,
			expectExec:  true,
		},
		{
			name:        "redirect exactly at limit blocked",
			level:       LevelRedirect,
			limit:       5,
			recentCount: 5,
			wantStatus:  http.StatusTooManyRequests,
			expectExec:  false,
		},
		{
			name:        "create under limit allowed",
			level:       LevelCreate,
			limit:       3,
			recentCount: 2,
			wantStatus:  http.StatusCreated,
			expectExec:  true,
		},
		{
			name:        "create exactly at limit blocked",
			level:       LevelCreate,
			limit:       3,
			recentCount: 3,
			wantStatus:  http.StatusTooManyRequests,
			expectExec:  false,
		},
		{
			name:        "default under limit allowed",
			level:       LevelDefault,
			limit:       7,
			recentCount: 6,
			wantStatus:  http.StatusCreated,
			expectExec:  true,
		},
		{
			name:        "default exactly at limit blocked",
			level:       LevelDefault,
			limit:       7,
			recentCount: 7,
			wantStatus:  http.StatusTooManyRequests,
			expectExec:  false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mock, done := setupRateLimitDB(t)
			defer done()

			cfg := &config.Config{
				DBQueryTimeout:                 3 * time.Second,
				RateLimitRedirectPerMinute:     9999,
				RateLimitAPILinksPostPerMinute: 9999,
				RateLimitAPIDefaultPerMinute:   9999,
			}
			switch tt.level {
			case LevelRedirect:
				cfg.RateLimitRedirectPerMinute = tt.limit
			case LevelCreate:
				cfg.RateLimitAPILinksPostPerMinute = tt.limit
			case LevelDefault:
				cfg.RateLimitAPIDefaultPerMinute = tt.limit
			}

			logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

			const (
				ip       = "192.168.1.1"
				endpoint = "/r"
			)
			mock.ExpectQuery(`SELECT COUNT\(\*\) FROM request_logs`).
				WithArgs(ip, endpoint).
				WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(tt.recentCount))

			if tt.expectExec {
				mock.ExpectExec(`INSERT INTO request_logs`).
					WithArgs(ip, endpoint, http.MethodGet, http.StatusCreated).
					WillReturnResult(sqlmock.NewResult(1, 1))
			}

			h := RateLimitMiddleware(cfg, logger, tt.level)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(http.StatusCreated)
			}))

			req := httptest.NewRequest(http.MethodGet, endpoint, nil)
			req.Header.Set("X-Forwarded-For", ip)
			rr := httptest.NewRecorder()
			h.ServeHTTP(rr, req)

			assert.Equal(t, tt.wantStatus, rr.Code)

			if tt.wantStatus == http.StatusTooManyRequests {
				var body map[string]any
				require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &body))
				assert.Len(t, body, 2)
				assert.Equal(t, "Too Many Requests", body["error"])
				assert.Equal(t, "Rate limit exceeded. Try again in a moment.", body["message"])
			}

			// For allowed requests we wait for async INSERT. For blocked requests
			// there must be no async INSERT expectation.
			if tt.expectExec {
				waitRateLimitAsyncMocks(t, mock, 1*time.Second)
			} else {
				require.NoError(t, mock.ExpectationsWereMet())
			}
		})
	}
}

func TestRateLimitMiddleware_BoundaryLimitReachedAllowed(t *testing.T) {
	// Requirement mapping:
	// - "exactly at limit should pass" -> this middleware blocks when recentCount >= limit,
	//   so the request that reaches the limit corresponds to recentCount == limit-1.
	const limit = 5
	const ip = "10.0.0.1"
	const endpoint = "/r"
	t.Run("passes at limit reached", func(t *testing.T) {
		mock, done := setupRateLimitDB(t)
		defer done()

		cfg := &config.Config{
			DBQueryTimeout:               3 * time.Second,
			RateLimitAPIDefaultPerMinute: limit,
		}
		logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

		mock.ExpectQuery(`SELECT COUNT\(\*\) FROM request_logs`).
			WithArgs(ip, endpoint).
			WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(int64(limit - 1)))

		h := RateLimitMiddleware(cfg, logger, LevelDefault)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusCreated)
		}))

		req := httptest.NewRequest(http.MethodGet, endpoint, nil)
		req.Header.Set("X-Forwarded-For", ip)
		rr := httptest.NewRecorder()
		h.ServeHTTP(rr, req)

		assert.Equal(t, http.StatusCreated, rr.Code)
		require.NoError(t, mock.ExpectationsWereMet())
	})

	t.Run("fails one above limit", func(t *testing.T) {
		mock, done := setupRateLimitDB(t)
		defer done()

		cfg := &config.Config{
			DBQueryTimeout:               3 * time.Second,
			RateLimitAPIDefaultPerMinute: limit,
		}
		logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

		mock.ExpectQuery(`SELECT COUNT\(\*\) FROM request_logs`).
			WithArgs(ip, endpoint).
			WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(int64(limit)))

		h := RateLimitMiddleware(cfg, logger, LevelDefault)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			t.Fatal("next must not run on rate limit breach")
		}))

		req := httptest.NewRequest(http.MethodGet, endpoint, nil)
		req.Header.Set("X-Forwarded-For", ip)
		rr := httptest.NewRecorder()
		h.ServeHTTP(rr, req)

		assert.Equal(t, http.StatusTooManyRequests, rr.Code)
		var body map[string]any
		require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &body))
		assert.Equal(t, "Too Many Requests", body["error"])
		assert.Equal(t, "Rate limit exceeded. Try again in a moment.", body["message"])
		require.NoError(t, mock.ExpectationsWereMet())
	})
}

func TestRateLimitMiddleware_LevelUsesCorrectLimit(t *testing.T) {
	tests := []struct {
		name     string
		level    RateLimitLevel
		redirect int
		create   int
		def      int
		wantCap  int
	}{
		{name: "redirect", level: LevelRedirect, redirect: 300, create: 60, def: 100, wantCap: 300},
		{name: "create", level: LevelCreate, redirect: 300, create: 60, def: 100, wantCap: 60},
		{name: "default", level: LevelDefault, redirect: 300, create: 60, def: 100, wantCap: 100},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mock, done := setupRateLimitDB(t)
			defer done()

			cfg := &config.Config{
				DBQueryTimeout:                 3 * time.Second,
				RateLimitRedirectPerMinute:     tt.redirect,
				RateLimitAPILinksPostPerMinute: tt.create,
				RateLimitAPIDefaultPerMinute:   tt.def,
			}
			logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

			// Boundary: at cap -> 429
			mock.ExpectQuery(`SELECT COUNT\(\*\) FROM request_logs`).
				WithArgs("10.0.0.1", "/x").
				WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(int64(tt.wantCap)))

			h := RateLimitMiddleware(cfg, logger, tt.level)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				t.Fatal("next must not run when limited")
			}))
			req := httptest.NewRequest(http.MethodGet, "/x", nil)
			req.Header.Set("X-Forwarded-For", "10.0.0.1")
			rr := httptest.NewRecorder()
			h.ServeHTTP(rr, req)

			assert.Equal(t, http.StatusTooManyRequests, rr.Code)
			require.NoError(t, mock.ExpectationsWereMet())
		})
	}
}

func TestRateLimitMiddleware_AsyncInsertDoesNotBlockHandler(t *testing.T) {
	mock, done := setupRateLimitDB(t)
	defer done()

	cfg := &config.Config{
		DBQueryTimeout:               3 * time.Second,
		RateLimitAPIDefaultPerMinute: 10,
	}
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

	mock.ExpectQuery(`SELECT COUNT\(\*\) FROM request_logs`).
		WithArgs("10.0.0.1", "/slow-insert").
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectExec(`INSERT INTO request_logs`).
		WithArgs("10.0.0.1", "/slow-insert", "GET", 200).
		WillDelayFor(400 * time.Millisecond).
		WillReturnResult(sqlmock.NewResult(1, 1))

	next := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})
	h := RateLimitMiddleware(cfg, logger, LevelDefault)(next)

	req := httptest.NewRequest(http.MethodGet, "/slow-insert", nil)
	req.Header.Set("X-Forwarded-For", "10.0.0.1")
	rr := httptest.NewRecorder()

	h.ServeHTTP(rr, req)

	assert.Equal(t, http.StatusOK, rr.Code)
	// The middleware inserts request_logs asynchronously; the delayed INSERT
	// should not have completed by the time ServeHTTP returns.
	assert.Error(t, mock.ExpectationsWereMet(), "async INSERT must still be pending")

	waitRateLimitAsyncMocks(t, mock, 2*time.Second)
}

func TestRateLimitMiddleware_CountQueryErrorReturns500(t *testing.T) {
	mock, done := setupRateLimitDB(t)
	defer done()

	cfg := &config.Config{
		DBQueryTimeout:               3 * time.Second,
		RateLimitAPIDefaultPerMinute: 10,
	}
	logger := slog.New(slog.NewJSONHandler(io.Discard, nil))

	mock.ExpectQuery(`SELECT COUNT\(\*\) FROM request_logs`).
		WillReturnError(fmt.Errorf("count query failed: %w", errors.New("db down")))

	h := RateLimitMiddleware(cfg, logger, LevelDefault)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		t.Fatal("next must not run on count error")
	}))
	req := httptest.NewRequest(http.MethodGet, "/e", nil)
	rr := httptest.NewRecorder()
	h.ServeHTTP(rr, req)

	assert.Equal(t, http.StatusInternalServerError, rr.Code)
	var body map[string]any
	require.NoError(t, json.Unmarshal(rr.Body.Bytes(), &body))
	assert.Len(t, body, 2)
	assert.Equal(t, "Internal Server Error", body["error"])
	assert.Equal(t, "Internal error", body["message"])
	require.NoError(t, mock.ExpectationsWereMet())
}
