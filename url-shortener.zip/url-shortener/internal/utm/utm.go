package utm

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"time"

	"gitlab.com/vishal101/url-shortener/internal/config"
)

// LogClick records an analytics row into the clicks table.
// It is intended to be called from a goroutine and never panics.
func LogClick(db *sql.DB, cfg *config.Config, ip, referrer, userAgent string, urlID int64) {
	defer func() {
		if r := recover(); r != nil {
			slog.Error("utm logger panicked", "recover", r)
		}
	}()
	if db == nil || cfg == nil || urlID <= 0 {
		return
	}

	start := time.Now()
	ip = safeTrim(ip)
	country := ""

	if ip != "" {
		var err error
		country, err = fetchCountry(cfg, ip)
		if err != nil {
			// Requirement: if ip-api.com fails — log and store empty string for country.
			slog.Error("ip lookup failed; storing empty country", "ip", ip, "error", err)
			country = ""
		}
	}

	ctx, cancel := context.WithTimeout(context.Background(), cfg.DBQueryTimeout)
	defer cancel()

	_, err := db.ExecContext(
		ctx,
		`INSERT INTO clicks (url_id, referrer, user_agent, country, ip_address, clicked_at) 
		 VALUES (?, ?, ?, ?, ?, UTC_TIMESTAMP())`,
		urlID,
		referrer,
		userAgent,
		country,
		ip,
	)
	if err != nil {
		if errors.Is(err, context.DeadlineExceeded) {
			slog.Error("db timeout", "duration_ms", time.Since(start).Milliseconds(), "op", "utm_insert_clicks", "url_id", urlID, "error", err)
		} else {
			slog.Error("failed to insert click analytics", "url_id", urlID, "error", err)
		}
		return
	}
}

type ipApiResponse struct {
	Status  string `json:"status"`
	Country string `json:"country"`
}

func fetchCountry(cfg *config.Config, ip string) (string, error) {
	if cfg == nil {
		return "", errors.New("config is nil")
	}

	client := &http.Client{
		Timeout: cfg.IPLookupTimeout,
	}

	u := cfg.IPLookupBaseURL + ip
	ctx, cancel := context.WithTimeout(context.Background(), cfg.IPLookupTimeout)
	defer cancel()

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	if err != nil {
		return "", fmt.Errorf("create request: %w", err)
	}

	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("ip-api request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", fmt.Errorf("ip-api non-2xx: %s", resp.Status)
	}

	var out ipApiResponse
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return "", fmt.Errorf("decode ip-api response: %w", err)
	}

	if out.Status != "success" {
		return "", fmt.Errorf("ip-api status: %s", out.Status)
	}
	return out.Country, nil
}

func safeTrim(s string) string {
	// Avoid unnecessary DB whitespace issues and keep logs tidy.
	for len(s) > 0 && (s[0] == ' ' || s[0] == '\n' || s[0] == '\r' || s[0] == '\t') {
		s = s[1:]
	}
	for len(s) > 0 {
		last := s[len(s)-1]
		if last == ' ' || last == '\n' || last == '\r' || last == '\t' {
			s = s[:len(s)-1]
			continue
		}
		break
	}
	return s
}

