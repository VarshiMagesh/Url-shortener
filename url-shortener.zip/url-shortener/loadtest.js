import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Rate, Trend, Counter } from 'k6/metrics';

// Custom metrics
const redirectLatency = new Trend('redirect_latency');
const createLatency = new Trend('create_latency');
const errorRate = new Rate('error_rate');
const cacheHits = new Counter('cache_hits');
const cacheMisses = new Counter('cache_misses');

// Configuration
const BASE_URL = 'http://localhost:8080';
const API_KEY = 'test-key-local';
const SHORT_CODE = 'REPLACE_WITH_YOUR_SHORT_CODE';

export const options = {
    scenarios: {

        // Scenario 1 — Steady redirect load
        // Simulates normal day to day traffic
        steady_redirects: {
            executor: 'constant-vus',
            vus: 50,
            duration: '30s',
            tags: { scenario: 'steady_redirects' },
            startTime: '0s',
        },

        // Scenario 2 — Traffic spike
        // Simulates a popular link being shared on LinkedIn suddenly
        traffic_spike: {
            executor: 'ramping-vus',
            startVUs: 0,
            stages: [
                { duration: '10s', target: 200 },  // ramp up to 200 users
                { duration: '20s', target: 200 },  // hold at 200
                { duration: '10s', target: 0 },    // ramp down
            ],
            tags: { scenario: 'traffic_spike' },
            startTime: '35s',
        },

        // Scenario 3 — Sustained high load
        // Simulates 1M+ redirects per month
        sustained_load: {
            executor: 'constant-arrival-rate',
            rate: 100,           // 100 requests per second
            timeUnit: '1s',
            duration: '30s',
            preAllocatedVUs: 50,
            maxVUs: 200,
            tags: { scenario: 'sustained_load' },
            startTime: '80s',
        },

        // Scenario 4 — Link creation load
        // Simulates 100k links per month creation rate
        link_creation: {
            executor: 'constant-vus',
            vus: 10,
            duration: '30s',
            tags: { scenario: 'link_creation' },
            startTime: '115s',
        },

    },

    thresholds: {
        // Redirect must be fast — p95 under 100ms, p99 under 200ms
        'http_req_duration{scenario:steady_redirects}': ['p(95)<100', 'p(99)<200'],
        'http_req_duration{scenario:traffic_spike}': ['p(95)<200', 'p(99)<500'],
        'http_req_duration{scenario:sustained_load}': ['p(95)<100', 'p(99)<200'],

        // Link creation can be slightly slower
        'http_req_duration{scenario:link_creation}': ['p(95)<500'],

        // Error rate must stay under 1% for redirects
        'http_req_failed{scenario:steady_redirects}': ['rate<0.01'],
        'http_req_failed{scenario:traffic_spike}': ['rate<0.05'],
        'http_req_failed{scenario:sustained_load}': ['rate<0.01'],

        // Custom metrics
        'redirect_latency': ['p(95)<100'],
        'error_rate': ['rate<0.01'],
    },
};

// Redirect test function
function testRedirect() {
    const start = Date.now();

    const res = http.get(`${BASE_URL}/${SHORT_CODE}`, {
        redirects: 0,
        tags: { endpoint: 'redirect' },
    });

    const duration = Date.now() - start;
    redirectLatency.add(duration);

    const success = check(res, {
        'redirect returns 302': (r) => r.status === 302,
        'has Location header': (r) => r.headers['Location'] !== undefined,
        'redirect is fast under 100ms': (r) => r.timings.duration < 100,
    });

    if (!success) {
        errorRate.add(1);
    } else {
        errorRate.add(0);
    }

    // Track cache performance from response time
    if (res.timings.duration < 5) {
        cacheHits.add(1);
    } else {
        cacheMisses.add(1);
    }
}

// Link creation test function
function testCreateLink() {
    const start = Date.now();

    const payload = JSON.stringify({
        long_url: `https://xobin.com/job-${Math.random().toString(36).substring(7)}`,
        created_by: 'loadtest@xobin.com',
    });

    const res = http.post(
        `${BASE_URL}/api/links`,
        payload,
        {
            headers: {
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Type': 'application/json',
            },
            tags: { endpoint: 'create_link' },
        }
    );

    const duration = Date.now() - start;
    createLatency.add(duration);

    check(res, {
        'link created successfully': (r) => r.status === 201,
        'response has short_url': (r) => JSON.parse(r.body).short_url !== undefined,
        'response has short_code': (r) => JSON.parse(r.body).short_code !== undefined,
    });
}

// Main function — runs based on which scenario is active
export default function () {
    const scenario = __ENV.SCENARIO || 'redirect';

    if (scenario === 'create') {
        group('Link Creation', () => {
            testCreateLink();
            sleep(1);
        });
    } else {
        group('Redirect', () => {
            testRedirect();
            sleep(0.1);
        });
    }
}

// Summary report at the end
export function handleSummary(data) {
    return {
        'loadtest-summary.json': JSON.stringify(data, null, 2),
        stdout: textSummary(data),
    };
}

function textSummary(data) {
    const metrics = data.metrics;
    return `
========================================
XOBIN URL SHORTENER — LOAD TEST RESULTS
========================================

REDIRECT PERFORMANCE
  p50 latency:  ${Math.round(metrics.http_req_duration?.values?.['p(50)'] || 0)}ms
  p95 latency:  ${Math.round(metrics.http_req_duration?.values?.['p(95)'] || 0)}ms
  p99 latency:  ${Math.round(metrics.http_req_duration?.values?.['p(99)'] || 0)}ms
  Max latency:  ${Math.round(metrics.http_req_duration?.values?.max || 0)}ms

THROUGHPUT
  Total requests:     ${metrics.http_reqs?.values?.count || 0}
  Requests/sec:       ${Math.round(metrics.http_reqs?.values?.rate || 0)}
  
ERROR RATE
  Failed requests:    ${metrics.http_req_failed?.values?.rate
        ? (metrics.http_req_failed.values.rate * 100).toFixed(2)
        : '0.00'}%

CACHE PERFORMANCE
  Cache hits:   ${metrics.cache_hits?.values?.count || 0}
  Cache misses: ${metrics.cache_misses?.values?.count || 0}

THRESHOLDS
${Object.entries(data.thresholds || {})
        .map(([name, result]) =>
            `  ${result.ok ? '✓' : '✗'} ${name}`
        )
        .join('\n')}

========================================
`;
}